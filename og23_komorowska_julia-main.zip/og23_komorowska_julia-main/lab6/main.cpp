#include <stdio.h>
#include <GL/glew.h>
#include <GL/freeglut.h>
#include <fstream>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <time.h>
#include <SOIL/SOIL.h>
#include <GL/glew.h>
#include <GL/freeglut.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
# define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#include "obj_loader.hpp"

//Problemy:
//Matowe i shine chyba nie tak
//czy oswietlenie kierunkowe git i inne oswietlenia
// jak z tymi sferami


bool useBlinnPhong = false;
bool usePhongReflect=false;

bool useLight = false;
bool animatePunkt = false;
bool punkt = false;
int color= 0;
bool isDirectionalLight = false;
bool showPointLightSpheres=false;
// Macierze transformacji i rzutowania
glm::mat4 matModel;
glm::mat4 matModel2;
glm::mat4 matView;
glm::mat4 matProj;

glm::mat4 matModelMonkey;
glm::mat4 matModeltruskawka;
glm::mat4 matModelCube;
glm::mat4 matModelSphere;

// Zmienne do kontroli obrotu obiektu
GLfloat angleY;
GLfloat angleX;
GLfloat angleXCube;
GLfloat angleYCube;
GLfloat redIntensity;
GLfloat height=2;
float lightMovementSpeed = 0.1f;  // Prędkość animacji
float lightPositionX = 2.0f;

GLfloat cameraDistance=-10;

using glm::vec3;
struct LightParam
{
    vec3 Ambient;
    vec3 Diffuse;
    vec3 Specular;
    vec3 Attenuation;
    vec3 Position; // Direction dla kierunkowego
};
struct LightParam redLight =
{
    vec3(0.2, 0.1, 0.1),   // ambient
    vec3(1.0, 0.0, 0.0),   // diffuse
    vec3(1.0, 0.0, 0.0),   // specular
    vec3(1.0, 0.0, 0.1),   // attenuation
    vec3(8.0, 3.0, 1.0)    // position

};

struct LightParam greenLight =
{
    vec3(0.1, 0.1, 0.1),   // ambient
    vec3(0.0, 1.0, 0.0),   // diffuse
    vec3(0.0, 1.0, 0.0),   // specular
    vec3(1.0, 0.0, 0.1),   // attenuation
    vec3(-4.0, 3.0, 1.0)   // position
};

struct LightParam blueLight =
{
    vec3(0.1, 0.1, 0.1),   // ambient
    vec3(0.0, 0.0, 1.0),   // diffuse
    vec3(0.0, 0.0, 1.0),   // specular
    vec3(1.0, 0.0, 0.1),   // attenuation
    vec3(6.0, 2.0, 4.0)   // position
};


// Struktura materialu obiektu
struct MaterialParam
{
    vec3 Ambient;
    vec3 Diffuse;
    vec3 Specular;
    float Shininess;
};

// Przykladowy material
struct MaterialParam myMaterial =
{
    vec3 (0.2, 0.2, 0.2),   // ambient
    vec3 (1.0, 1.0, 1.0),   // diffuse
    vec3 (1.5, 1.0, 1.0),   // specular
    1.0 // shininess
};
struct MaterialParam myMaterialMatte =
{
    vec3(0.2, 0.2, 0.2),   // ambient
    vec3(1.0, 1.0, 1.0),   // diffuse
    vec3(0.0, 0.0, 0.0),   // specular (set to zero for matte appearance)
    1.0                   // shininess (set to zero for matte appearance)
};

struct MaterialParam myMaterialShine =
{
    vec3 (0.2, 0.2, 0.2),   // ambient
    vec3 (1.0, 1.0, 1.0),   // diffuse (you might want to adjust this)
    vec3(2.0, 2.0, 2.0),   // specular (adjust as needed for shiny appearance)
    40.0                   // shininess (adjust as needed for shiny appearance)
};
// Przykladowe swiatlo punktowe
struct LightParam myLight =
{
    vec3 (0.1, 0.1, 0.1),   // ambient
    vec3 (1.0, 1.0, 1.0),   // diffuse
    vec3 (1.0, 1.0, 1.0),   // specular
    vec3 (1.0, 0.0, 0.1),   // attenuation
    vec3 (2.0, 3.0, 1.0)    // position

};
void SentLightParameters()
{
    GLint idProgram = 0;
    glGetIntegerv(GL_CURRENT_PROGRAM, &idProgram);

    //wysylanie
    glUniform3fv(glGetUniformLocation(idProgram,"myLight.Ambient"), 1, glm::value_ptr(myLight.Ambient));
    glUniform3fv(glGetUniformLocation(idProgram,"myLight.Diffuse"), 1, glm::value_ptr(myLight.Diffuse));
    glUniform3fv(glGetUniformLocation(idProgram,"myLight.Specular"), 1, glm::value_ptr(myLight.Specular));
    glUniform3fv(glGetUniformLocation(idProgram,"myLight.Attenuation"), 1, glm::value_ptr(myLight.Attenuation));
    glUniform3fv(glGetUniformLocation(idProgram,"myLight.Position"), 1, glm::value_ptr(myLight.Position));

    glUniform3fv(glGetUniformLocation(idProgram,"redLight.Ambient"), 1, glm::value_ptr(redLight.Ambient));
    glUniform3fv(glGetUniformLocation(idProgram,"redLight.Diffuse"), 1, glm::value_ptr(redLight.Diffuse));
    glUniform3fv(glGetUniformLocation(idProgram,"redLight.Specular"), 1, glm::value_ptr(redLight.Specular));
    glUniform3fv(glGetUniformLocation(idProgram,"redLight.Attenuation"), 1, glm::value_ptr(redLight.Attenuation));
    glUniform3fv(glGetUniformLocation(idProgram,"redLight.Position"), 1, glm::value_ptr(redLight.Position));

    glUniform3fv(glGetUniformLocation(idProgram,"greenLight.Ambient"), 1, glm::value_ptr(greenLight.Ambient));
    glUniform3fv(glGetUniformLocation(idProgram,"greenLight.Diffuse"), 1, glm::value_ptr(greenLight.Diffuse));
    glUniform3fv(glGetUniformLocation(idProgram,"greenLight.Specular"), 1, glm::value_ptr(greenLight.Specular));
    glUniform3fv(glGetUniformLocation(idProgram,"greenLight.Attenuation"), 1, glm::value_ptr(greenLight.Attenuation));
    glUniform3fv(glGetUniformLocation(idProgram,"greenLight.Position"), 1, glm::value_ptr(greenLight.Position));

    glUniform3fv(glGetUniformLocation(idProgram,"blueLight.Ambient"), 1, glm::value_ptr(blueLight.Ambient));
    glUniform3fv(glGetUniformLocation(idProgram,"blueLight.Diffuse"), 1, glm::value_ptr(blueLight.Diffuse));
    glUniform3fv(glGetUniformLocation(idProgram,"blueLight.Specular"), 1, glm::value_ptr(blueLight.Specular));
    glUniform3fv(glGetUniformLocation(idProgram,"blueLight.Attenuation"), 1, glm::value_ptr(blueLight.Attenuation));
    glUniform3fv(glGetUniformLocation(idProgram,"blueLight.Position"), 1, glm::value_ptr(blueLight.Position));
};
void SentMaterialParameters()
{
    GLint idProgram = 0;
    glGetIntegerv(GL_CURRENT_PROGRAM, &idProgram);

    //wysylanie
    glUniform3fv(glGetUniformLocation(idProgram,"myMaterial.Ambient"), 1, glm::value_ptr(myMaterial.Ambient));
    glUniform3fv(glGetUniformLocation(idProgram,"myMaterial.Diffuse"), 1, glm::value_ptr(myMaterial.Diffuse));
    glUniform3fv(glGetUniformLocation(idProgram,"myMaterial.Specular"), 1, glm::value_ptr(myMaterial.Specular));
    glUniform1f(glGetUniformLocation(idProgram,"myMaterial.Shininess"), myMaterial.Shininess);

};

struct Texture
{
    GLuint id;       // Identyfikator tekstury
    int width;       // Szerokość tekstury
    int height;      // Wysokość tekstury
    unsigned char* image;  // Obraz tekstury
};

struct Material
{
    Texture texture;  // Tekstura materiału
    // Dodaj inne właściwości materiału, jeśli są potrzebne
};
Texture LoadTexture(const char* filename);
class CProgram
{
public:
    GLuint idProgram;
    void CreateProgram()
    {
        idProgram = glCreateProgram();
    }
    void Use()
    {
        glUseProgram( idProgram );
    }
    void LoadShaders(char* vertex_filename, char* fragment_filename)
    {
        glAttachShader( idProgram, LoadShader(GL_VERTEX_SHADER, vertex_filename));
        glAttachShader( idProgram, LoadShader(GL_FRAGMENT_SHADER, fragment_filename));
    }
    void LinkAndValidate()
    {
        LinkAndValidateProgram( idProgram );
    }
    void SetMVP(glm::mat4 matModel,glm::mat4 matView,glm::mat4 matProj,bool useTexture)
    {
        glm::vec3 cameraPos = ExtractCameraPos(matView);
        glUniformMatrix4fv( glGetUniformLocation(idProgram, "matProj"), 1, GL_FALSE, glm::value_ptr(matProj) );
        glUniformMatrix4fv( glGetUniformLocation(idProgram, "matView"), 1, GL_FALSE, glm::value_ptr(matView) );
        glUniformMatrix4fv( glGetUniformLocation(idProgram, "matModel"), 1, GL_FALSE, glm::value_ptr(matModel) );
        glUniform1i(glGetUniformLocation(idProgram, "useTexture"), useTexture);

        glUniform1i(glGetUniformLocation(idProgram, "isDirectionalLight"), isDirectionalLight);
        glUniform3fv(glGetUniformLocation(idProgram,"myLight.Direction"), 1, glm::value_ptr(myLight.Position));
        glUniform1i(glGetUniformLocation(idProgram,"showPointLightSpheres"), showPointLightSpheres);
        glUniform1i(glGetUniformLocation(idProgram, "punkt"), punkt);
        glUniform1i(glGetUniformLocation(idProgram, "usePhongReflect"), usePhongReflect);


        // Przekazanie pozycji kamery
        glUniform3fv( glGetUniformLocation( idProgram, "cameraPos" ), 1, &cameraPos[0] );


        //SentMaterialParameters();
        SentLightParameters();

    }
    void Clean()
    {
        glDeleteProgram( idProgram );
    }

};
class CMesh
{
public:
    std::vector<glm::vec3> vertices;
    std::vector<glm::vec2> uvs;
    std::vector<glm::vec3> normals;
    GLuint idVAO;		// tablic wierzcholkow
    GLuint idVBO_coord;	// bufor wspolrzednych
    GLuint idVBO_color; // bufor na kolory
    GLuint idVBO_texCoord;  // bufor na współrzęd
    GLuint idVBO_normal; // bufor na koloryne tekstur

    Material material;  // informacje o materiale

    // Metody tworzaca VAO i VBO z pliku OBJ
    void CreateFromOBJ(char* filename)
    {

        // Wczytanie pliku OBJ
        if (!loadOBJ(filename, vertices, uvs, normals))
        {
            printf("File not loaded!\n");
        }

        printf("Loaded %d vertices\n", vertices.size());


        // Wykorzystamy dane wczytane z pliku OBJ
        // do stworzenia buforow w VAO
        glGenVertexArrays( 1, &idVAO );
        glBindVertexArray( idVAO );
        // Bufor na wspolrzedne wierzcholkow
        glGenBuffers( 1, &idVBO_coord );
        glBindBuffer( GL_ARRAY_BUFFER, idVBO_coord );
        glBufferData( GL_ARRAY_BUFFER, sizeof( glm::vec3 ) * vertices.size(), &vertices[0], GL_STATIC_DRAW );
        glVertexAttribPointer( 0, 3, GL_FLOAT, GL_FALSE, 0, NULL );
        glEnableVertexAttribArray( 0 );
        glGenBuffers( 1, &idVBO_normal );
        glBindBuffer( GL_ARRAY_BUFFER, idVBO_normal );
        glBufferData( GL_ARRAY_BUFFER, normals.size() * sizeof(glm::vec3), &normals[0], GL_STATIC_DRAW );
        glVertexAttribPointer( 1, 3, GL_FLOAT, GL_FALSE, 0, NULL );
        glEnableVertexAttribArray( 1);
        // Bufor na wierzchloki textury
        glGenBuffers( 1, &idVBO_texCoord );
        glBindBuffer( GL_ARRAY_BUFFER, idVBO_texCoord );
        glBufferData( GL_ARRAY_BUFFER, sizeof( glm::vec2 ) * uvs.size(), &uvs[0], GL_STATIC_DRAW );
        glVertexAttribPointer( 2, 2, GL_FLOAT, GL_FALSE, 0, NULL );
        glEnableVertexAttribArray( 2 );
        glBindVertexArray( 0 );


    }

    //metoda generujaca obraz na ekranie
    void Draw()
    {

        glBindVertexArray( idVAO );
        glDrawArrays( GL_TRIANGLES, 0, vertices.size() );
        glBindVertexArray( 0 );
    }
    void Clean()
    {
        glDeleteVertexArrays( 1, &idVBO_coord );
        glDeleteVertexArrays( 1, &idVBO_texCoord );
        glDeleteVertexArrays( 1, &idVBO_color );
        glDeleteVertexArrays( 1, &idVAO );
    }

};


CProgram glownyProgram, truskawkaProgram, monkeyProgram, cubeProgram,sphereProgram;
CMesh truskawka3D, ground3D, monkey3D, cube3D,sphere3D;


Texture LoadTexture(const char* filename)
{
    Texture texture;
    glGenTextures(1, &texture.id);
    glBindTexture(GL_TEXTURE_2D, texture.id);

    int width, height,n;
    unsigned char* image = stbi_load (filename, &width, &height, &n,0);

    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);


    texture.width = width;
    texture.height = height;

    return texture;
}
bool heightBool= true;
clock_t last_T = 0;
void Animation ()
{
    clock_t now_T = clock ();
    double delta_T = now_T - last_T ;
    if( delta_T > 6) // miliseconds
    {
        if(height<4.0f && heightBool)
        {
            height += 0.01f;
        }
        else
        {
            heightBool=false;
            height -= 0.01f;
            if(height < 3.0f)
            {
                heightBool= true;
            }
        }
        angleXCube += 0.001f;
        angleYCube += 0.005f;
        glutPostRedisplay ();
        last_T = now_T ;
    }
    if(animatePunkt)
    {
        lightPositionX += lightMovementSpeed;  // Aktualizacja pozycji światła punktowego
        if (lightPositionX > 5.0f || lightPositionX < -5.0f)
        {
            lightMovementSpeed = -lightMovementSpeed;  // Zmiana kierunku animacji
        }
    }

}
void Menu(int value)
{
    switch (value)
    {
    case 1:
        isDirectionalLight=false;

        useLight=true;
        animatePunkt=false;
        punkt = false;
        usePhongReflect=false;

        showPointLightSpheres = false;
        useBlinnPhong = true;
        myLight = LightParam
        {
            vec3(0.1, 0.1, 0.1), // ambient
            vec3(1.0, 0.0, 0.0), // diffuse
            vec3(1.0, 0.0, 0.0), // specular
            vec3(1.0, 0.0, 0.1), // attenuation
            vec3(2.0, 3.0, 1.0)  // position
        };
        break;

    case 2:
        useBlinnPhong = false;
        usePhongReflect=true;
        isDirectionalLight=false;
        showPointLightSpheres = false;
        useLight=true;
        punkt = false;
        animatePunkt=false;
        myLight = LightParam
        {
            vec3(0.1, 0.1, 0.1), // ambient
            vec3(1.0, 1.0, 1.0), // diffuse
            vec3(1.0, 1.0, 1.0), // specular
            vec3(1.0, 0.0, 0.1), // attenuation
            vec3(2.0, 3.0, 1.0)  // position
        };
        break;
    case 3:
        useLight=true;
        useBlinnPhong = false;

        animatePunkt=true;
        showPointLightSpheres = true;
        punkt=true;
        usePhongReflect=false;

        isDirectionalLight=false;
        myLight = LightParam
        {

            vec3 (0.1, 0.1, 0.1),   // ambient
            vec3 (1.0, 1.0, 1.0),   // diffuse
            vec3 (1.0, 1.0, 1.0),   // specular
            vec3 (1.0, 0.0, 0.0),   // attenuation
            vec3 (2.0, 1.0, 1.0)    // position

        };
        break;

    case 4:
        isDirectionalLight=false;
        useBlinnPhong = false;
        usePhongReflect=false;

        showPointLightSpheres = false;
        punkt = false;
        animatePunkt=false;
        useLight =false;
        break;
    case 5:
        useLight=true;
        useBlinnPhong = false;
        usePhongReflect=false;

        showPointLightSpheres = false;
        punkt=false;
        animatePunkt=false;
        isDirectionalLight=true;
        myLight = LightParam
        {
            vec3 (0.1, 0.1, 0.1),   // ambient
            vec3 (1.0, 1.0, 1.0),   // diffuse
            vec3 (1.0, 1.0, 1.0),   // specular
            vec3 (1.0, 0.0, 0.1),   // attenuation// attenuation (reduce attenuation)
            vec3(2.0, 3.0, 1.0)       // position
        };
        break;
    case 6:
        useLight=true;
        animatePunkt=false;
        useBlinnPhong = false;
        usePhongReflect=false;

        showPointLightSpheres = true;
        punkt=true;
        isDirectionalLight=false;
        myLight = LightParam
        {

            vec3 (0.1, 0.1, 0.1),   // ambient
            vec3 (1.0, 1.0, 1.0),   // diffuse
            vec3 (1.0, 1.0, 1.0),   // specular
            vec3 (1.0, 0.0, 0.0),   // attenuation
            vec3 (2.0, 1.0, 1.0)    // position

        };
        break;

    }
    glutPostRedisplay();
}
// ---------------------------------------
void DisplayScene()
{

    // Czyszczenie bufora koloru
    glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );


    // Obliczanie macierzy widoku (pozycja kamery)
    matView = glm::mat4(1.0);
     matView = glm::rotate(matView, angleX, glm::vec3(1.0, 0.0, 0.0));
    matView = glm::rotate(matView,angleY, glm::vec3(0.0, 1.0, 0.0));
    matView = glm::translate(matView, glm::vec3(0.0, -3.0, cameraDistance));
    glm::vec3 cameraPos = ExtractCameraPos(matView);
    // Macierz modelu obiektu
    matModel = glm::mat4(1.0);
    matModel = glm::rotate(matModel, 0.0f, glm::vec3(1.0, 0.0, 0.0));
    matModel = glm::rotate(matModel, 0.0f, glm::vec3(0.0, 1.0, 0.0));
    matModel = glm::translate(matModel, glm::vec3(0.0, 0.0, 0.0));
    myLight.Position.x = lightPositionX;

    // Wlaczenie potoku
    glownyProgram.Use();

    // Przekazujemy macierze modelu, widoku i rzutowania do potoku
    glownyProgram.SetMVP(matModel,matView,matProj,true);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, ground3D.material.texture.id);
    glUniform1i(glGetUniformLocation(glownyProgram.idProgram, "textureSampler"), 0);
    glUniform1i(glGetUniformLocation(glownyProgram.idProgram, "useBlinnPhong"), useBlinnPhong);
    glUniform1i(glGetUniformLocation(glownyProgram.idProgram, "useLight"), useLight);

    glUniform3fv(glGetUniformLocation(glownyProgram.idProgram,"myMaterial.Ambient"), 1, glm::value_ptr(myMaterial.Ambient));
    glUniform3fv(glGetUniformLocation(glownyProgram.idProgram,"myMaterial.Diffuse"), 1, glm::value_ptr(myMaterial.Diffuse));
    glUniform3fv(glGetUniformLocation(glownyProgram.idProgram,"myMaterial.Specular"), 1, glm::value_ptr(myMaterial.Specular));
    glUniform1f(glGetUniformLocation(glownyProgram.idProgram,"myMaterial.Shininess"), myMaterial.Shininess);



    SentLightParameters();
    // Uruchamianie potoku (rendering)
    ground3D.Draw();

    // Wylaczanie potoku
    glUseProgram( 0 );

    matModeltruskawka = glm::translate(matModel, glm::vec3(0.0, 0.2, 0.0));
    truskawkaProgram.Use();

    truskawkaProgram.SetMVP(matModeltruskawka,matView,matProj,true);
    glActiveTexture(GL_TEXTURE1);
    glBindTexture(GL_TEXTURE_2D, truskawka3D.material.texture.id);
    glUniform1i(glGetUniformLocation(truskawkaProgram.idProgram, "textureSampler"), 1);
    glUniform1i(glGetUniformLocation(truskawkaProgram.idProgram, "useLight"), useLight);
    glUniform3fv(glGetUniformLocation(truskawkaProgram.idProgram,"myMaterial.Ambient"), 1, glm::value_ptr(myMaterialShine.Ambient));
    glUniform3fv(glGetUniformLocation(truskawkaProgram.idProgram,"myMaterial.Diffuse"), 1, glm::value_ptr(myMaterialShine.Diffuse));
    glUniform3fv(glGetUniformLocation(truskawkaProgram.idProgram,"myMaterial.Specular"), 1, glm::value_ptr(myMaterialShine.Specular));
    glUniform1f(glGetUniformLocation(truskawkaProgram.idProgram,"myMaterial.Shininess"), myMaterialShine.Shininess);
    truskawka3D.Draw();
    glUseProgram( 0 );

    matModelMonkey = glm::translate(matModel, glm::vec3(0.0, height, 0.0));

    monkeyProgram.Use();
    glUniform1f(glGetUniformLocation(monkeyProgram.idProgram,"height"), height);

    monkeyProgram.SetMVP(matModelMonkey,matView,matProj,true);
    glActiveTexture(GL_TEXTURE2);
    glBindTexture(GL_TEXTURE_2D, monkey3D.material.texture.id);
    glUniform1i(glGetUniformLocation(monkeyProgram.idProgram, "textureSampler"), 2);
    glUniform1i(glGetUniformLocation(monkeyProgram.idProgram, "useLight"), useLight);
    //wysylanie
    glUniform3fv(glGetUniformLocation(monkeyProgram.idProgram,"myMaterial.Ambient"), 1, glm::value_ptr(myMaterial.Ambient));
    glUniform3fv(glGetUniformLocation(monkeyProgram.idProgram,"myMaterial.Diffuse"), 1, glm::value_ptr(myMaterial.Diffuse));
    glUniform3fv(glGetUniformLocation(monkeyProgram.idProgram,"myMaterial.Specular"), 1, glm::value_ptr(myMaterial.Specular));
    glUniform1f(glGetUniformLocation(monkeyProgram.idProgram,"myMaterial.Shininess"), myMaterial.Shininess);
    monkey3D.Draw();
    glUseProgram( 0 );

    matModelCube = glm::mat4(1.0);
    matModelCube = glm::translate(matModel, glm::vec3(-4.0, 1.0, -3.0));
    matModelCube = glm::rotate(matModelCube, angleXCube, glm::vec3(1.0, 0.0, 0.0));
    matModelCube = glm::rotate(matModelCube, angleYCube, glm::vec3(0.0, 1.0, 0.0));

    cubeProgram.Use();
    glUniform1f(glGetUniformLocation(cubeProgram.idProgram,"angleXCube"), angleXCube);
    glUniform1f(glGetUniformLocation(cubeProgram.idProgram,"angleYCube"), angleYCube);

    cubeProgram.SetMVP(matModelCube,matView,matProj,true);
    glActiveTexture(GL_TEXTURE3);
    glBindTexture(GL_TEXTURE_2D, cube3D.material.texture.id);
    glUniform1i(glGetUniformLocation(cubeProgram.idProgram, "textureSampler"), 3);
    glUniform1i(glGetUniformLocation(cubeProgram.idProgram, "useLight"), useLight);

    //wysylanie
    glUniform3fv(glGetUniformLocation(cubeProgram.idProgram,"myMaterial.Ambient"), 1, glm::value_ptr(myMaterialMatte.Ambient));
    glUniform3fv(glGetUniformLocation(cubeProgram.idProgram,"myMaterial.Diffuse"), 1, glm::value_ptr(myMaterialMatte.Diffuse));
    glUniform3fv(glGetUniformLocation(cubeProgram.idProgram,"myMaterial.Specular"), 1, glm::value_ptr(myMaterialMatte.Specular));
    glUniform1f(glGetUniformLocation(cubeProgram.idProgram,"myMaterial.Shininess"), myMaterialMatte.Shininess);
    cube3D.Draw();
    glUseProgram( 0 );
    if(showPointLightSpheres)
    {
        matModelSphere = glm::translate(matModel, redLight.Position);
        sphereProgram.Use();
        glUniform3fv(glGetUniformLocation(sphereProgram.idProgram,"myMaterial.Ambient"), 1, glm::value_ptr(myMaterial.Ambient));
        glUniform3fv(glGetUniformLocation(sphereProgram.idProgram,"myMaterial.Diffuse"), 1, glm::value_ptr(myMaterial.Diffuse));
        glUniform3fv(glGetUniformLocation(sphereProgram.idProgram,"myMaterial.Specular"), 1, glm::value_ptr(myMaterial.Specular));
        glUniform1f(glGetUniformLocation(sphereProgram.idProgram,"myMaterial.Shininess"), myMaterial.Shininess);
        glUniform1i(glGetUniformLocation(sphereProgram.idProgram, "useLight"), false);
        glUniform1i(glGetUniformLocation(sphereProgram.idProgram, "color"), 1);


        sphereProgram.SetMVP(matModelSphere,matView,matProj,false);
        sphere3D.Draw();
        glUseProgram( 0 );
        matModelSphere = glm::translate(matModel, greenLight.Position);
        sphereProgram.Use();
        glUniform3fv(glGetUniformLocation(sphereProgram.idProgram,"myMaterial.Ambient"), 1, glm::value_ptr(myMaterial.Ambient));
        glUniform3fv(glGetUniformLocation(sphereProgram.idProgram,"myMaterial.Diffuse"), 1, glm::value_ptr(myMaterial.Diffuse));
        glUniform3fv(glGetUniformLocation(sphereProgram.idProgram,"myMaterial.Specular"), 1, glm::value_ptr(myMaterial.Specular));
        glUniform1f(glGetUniformLocation(sphereProgram.idProgram,"myMaterial.Shininess"), myMaterial.Shininess);
        glUniform1i(glGetUniformLocation(sphereProgram.idProgram, "useLight"), false);
        glUniform1i(glGetUniformLocation(sphereProgram.idProgram, "color"), 2);


        sphereProgram.SetMVP(matModelSphere,matView,matProj,false);
        sphere3D.Draw();
        glUseProgram( 0 );

        matModelSphere = glm::translate(matModel, blueLight.Position );
        sphereProgram.Use();
        glUniform3fv(glGetUniformLocation(sphereProgram.idProgram,"myMaterial.Ambient"), 1, glm::value_ptr(myMaterial.Ambient));
        glUniform3fv(glGetUniformLocation(sphereProgram.idProgram,"myMaterial.Diffuse"), 1, glm::value_ptr(myMaterial.Diffuse));
        glUniform3fv(glGetUniformLocation(sphereProgram.idProgram,"myMaterial.Specular"), 1, glm::value_ptr(myMaterial.Specular));
        glUniform1f(glGetUniformLocation(sphereProgram.idProgram,"myMaterial.Shininess"), myMaterial.Shininess);
        glUniform1i(glGetUniformLocation(sphereProgram.idProgram, "useLight"), false);
        glUniform1i(glGetUniformLocation(sphereProgram.idProgram, "color"), 3);


        sphereProgram.SetMVP(matModelSphere,matView,matProj,false);
        sphere3D.Draw();
        glUseProgram( 0 );
        matModelSphere = glm::translate(matModel, myLight.Position);
        sphereProgram.Use();
        glUniform3fv(glGetUniformLocation(sphereProgram.idProgram,"myMaterial.Ambient"), 1, glm::value_ptr(myMaterial.Ambient));
        glUniform3fv(glGetUniformLocation(sphereProgram.idProgram,"myMaterial.Diffuse"), 1, glm::value_ptr(myMaterial.Diffuse));
        glUniform3fv(glGetUniformLocation(sphereProgram.idProgram,"myMaterial.Specular"), 1, glm::value_ptr(myMaterial.Specular));
        glUniform1f(glGetUniformLocation(sphereProgram.idProgram,"myMaterial.Shininess"), myMaterial.Shininess);
        glUniform1i(glGetUniformLocation(sphereProgram.idProgram, "useLight"), false);
        glUniform1i(glGetUniformLocation(sphereProgram.idProgram, "color"), 4);


        sphereProgram.SetMVP(matModelSphere,matView,matProj,false);
        sphere3D.Draw();
        glUseProgram( 0 );
    }

    glutSwapBuffers();
}

// ---------------------------------------
void Initialize()
{


    // Ustawianie koloru, ktorym bedzie czyszczony bufor koloru
    glClearColor( 0.5f, 0.5f, 0.5f, 1.0f );
    glEnable(GL_DEPTH_TEST);
    myLight.Position = vec3(lightPositionX, 3.0, 1.0);
    // Potok
    glownyProgram.CreateProgram();
    glownyProgram.LoadShaders("vertex.glsl", "fragment.glsl");
    glownyProgram.LinkAndValidate();

    truskawkaProgram.CreateProgram();
    truskawkaProgram.LoadShaders("vertex.glsl", "fragment.glsl");
    truskawkaProgram.LinkAndValidate();

    monkeyProgram.CreateProgram();
    monkeyProgram.LoadShaders("vertex.glsl", "fragment.glsl");
    monkeyProgram.LinkAndValidate();

    cubeProgram.CreateProgram();
    cubeProgram.LoadShaders("vertex.glsl", "fragment.glsl");
    cubeProgram.LinkAndValidate();

    sphereProgram.CreateProgram();
    sphereProgram.LoadShaders("vertex.glsl", "fragment.glsl");
    sphereProgram.LinkAndValidate();



    truskawka3D.CreateFromOBJ("truskawka.obj");
    ground3D.CreateFromOBJ("ground-large.obj");
    monkey3D.CreateFromOBJ("monkey.obj");
    cube3D.CreateFromOBJ("cube.obj");
    sphere3D.CreateFromOBJ("sphere.obj");

    truskawka3D.material.texture = LoadTexture("truskawka_texture.jpg");
    ground3D.material.texture = LoadTexture("ground_texture.jpg");
    monkey3D.material.texture = LoadTexture("monkey_texture.jpg");
    cube3D.material.texture = LoadTexture("cube_texture.jpg");

}

// ---------------------------------------
void Reshape( int width, int height )
{
    glViewport( 0, 0, width, height );

    // Obliczanie macierzy rzutowania perspektywicznego
    matProj = glm::perspective(glm::radians(90.0f), width/(float)height, 0.1f, 40.0f );

}

// ---------------------------------------------------
void Keyboard( unsigned char key, int x, int y )
{
    switch(key)
    {
    case 27:	// ESC key
        exit(0);
        break;

    case 'w':
        angleX += 0.1f;
        break;

    case 's':
        angleX -= 0.1f;
        break;

    case 'd':
        angleY -= 0.1f;
        break;

    case 'a':
        angleY += 0.1f;
        break;

    case '+':
        cameraDistance += 0.1f;
        break;

    case '-':
        cameraDistance -= 0.1f;
        break;
    }
    //glutPostRedisplay();
}

// ---------------------------------------------------
int main( int argc, char *argv[] )
{
    // GLUT
    glutInit( &argc, argv );
    glutInitDisplayMode( GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH );
    //Menu inaczej mi nie działa
    //glutInitContextVersion( 3, 2 );
    //glutInitContextProfile( GLUT_CORE_PROFILE );
    glutInitWindowSize( 500, 500 );
    glutCreateWindow( "Zadanie 1" );
    glutDisplayFunc( DisplayScene );
    glutReshapeFunc( Reshape );
    glutMouseFunc( MouseButton );
    glutMotionFunc( MouseMotion );
    glutMouseWheelFunc( MouseWheel );
    glutKeyboardFunc( Keyboard );
    glutSpecialFunc( SpecialKeys );
    // GLEW
    glewExperimental = GL_TRUE;
    GLenum err = glewInit();
    if( GLEW_OK != err )
    {
        printf("GLEW Error\n");
        exit(1);
    }

    // OpenGL
    if( !GLEW_VERSION_3_2 )
    {
        printf("Brak OpenGL 3.2!\n");
        exit(1);
    }
    int podmenuA = glutCreateMenu( Menu );
    glutAddMenuEntry( "Phong- Animacja", 3 );
    glutAddMenuEntry( "Phong", 6 );
    glutAddMenuEntry( "Kierunkowe", 5 );

    // Kolejne podmenu
    int podmenuB = glutCreateMenu( Menu );
    glutAddMenuEntry( "Bling-Phong", 1 );
    glutAddMenuEntry( "Phong", 2 );

    // Na koniec utworzenie glownego menu
    // wraz z podaniem funkcji zwrotnej
    // ktora wyzej napisalismy

    glutCreateMenu( Menu );
    glutAddSubMenu( "Punktowe & Kierunkowe", podmenuA );
    glutAddSubMenu( "Odbiciowe", podmenuB );
    glutAddMenuEntry( "Nic", 4 );
    glutAttachMenu( GLUT_RIGHT_BUTTON );

    glutIdleFunc ( Animation );
    Initialize();

    glutMainLoop();


    // Cleaning
    glownyProgram.Clean();
    ground3D.Clean();

    truskawkaProgram.Clean();
    truskawka3D.Clean();

    cubeProgram.Clean();
    cube3D.Clean();

    monkeyProgram.Clean();
    monkey3D.Clean();

    return 0;
}
