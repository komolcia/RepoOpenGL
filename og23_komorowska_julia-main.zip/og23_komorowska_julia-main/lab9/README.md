# lab9
## Zrealizowane wszystko
![img.png](../screeny/img_15.png)
