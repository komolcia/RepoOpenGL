# lab7
## Zrealizowane wszystko
![img.png](../screeny/img_14.png)
