#include <stdio.h>
#include <GL/glew.h>
#include <GL/freeglut.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

// Lokalne pliki naglowkowe
#include "utilities.hpp"

// NOWE: plik do obslugi plikow graficznych
# define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

// Macierze transformacji i rzutowania
glm::mat4 matProj = glm::mat4(1.0);
glm::mat4 matView = glm::mat4(1.0);
glm::mat4 matModel = glm::mat4(1.0);

// Identyfikatory obiektow
GLuint idProgram;
GLuint idVAO;
GLuint idVBO_coord;
GLuint idVBO_color;
GLuint idVBO_uv;
const int numFrames = 15;
int currentFrame = 2;
const int frameDuration = 1000/60;

int lastFrameChangeTime = 0;

GLuint idTexture;

// Dane prostokąta
GLfloat vertices_coord[] =
{
    -1.0f, -1.0f, 0.0f,
     1.0f, -1.0f, 0.0f,
    -1.0f,  1.5f, 0.0f,

    -1.0f, 1.5f, 0.0f,
     1.0f, -1.0f, 0.0f,
     1.0f, 1.5f, 0.0f,
};

GLfloat vertices_color[] =
{
    1.0f, 0.0f, 0.0f,
    0.0f, 1.0f, 0.0f,
    0.0f, 0.0f, 1.0f,

    0.5f, 0.5f, 0.0f,
    0.0f, 0.5f, 0.5f,
    0.5f, 0.0f, 0.5f,
};

GLfloat vertices_uv[] =
{
    0.0f, 0.0f,
    1.0f, 0.0f,
    0.0f, 1.0f,

    0.0f, 1.0f,
    1.0f, 0.0f,
    1.0f, 1.0f,
};
GLfloat vertices_uv2[] =
{
    0.0f, 0.0f,
    1.0f, 0.0f,
    0.0f, 1.0f,

    0.0f, 1.0f,
    1.0f, 0.0f,
    1.0f, 1.0f,
};

void Animation(int value)
{
    // Aktualizacja klatki animacji

    // Ponowne ustawienie timera
    glutTimerFunc(1000/20, Animation, 0);

    // Ponowne rysowanie sceny
    glutPostRedisplay();
}

// ---------------------------------------
void DisplayScene()
{
    // Czyszczenie bufora koloru i glebokosci
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    // Obliczanie macierzy widoku
    matView = UpdateViewMatrix();

    // Wlaczenie programu
    glUseProgram(idProgram);

    // Przekazanie macierzy
    glUniformMatrix4fv(glGetUniformLocation(idProgram, "matProj"), 1, GL_FALSE, glm::value_ptr(matProj));
    glUniformMatrix4fv(glGetUniformLocation(idProgram, "matView"), 1, GL_FALSE, glm::value_ptr(matView));
    glUniformMatrix4fv(glGetUniformLocation(idProgram, "matModel"), 1, GL_FALSE, glm::value_ptr(matModel));

        currentFrame = (currentFrame + 1) % numFrames;


        // Modyfikacja współrzędnych UV na podstawie aktualnej klatki
        GLfloat frameWidth = 1.0f / numFrames;
        GLfloat xOffset = currentFrame * frameWidth;
        for (int i = 0; i < 12; i +=2)
        {
            vertices_uv[i] = vertices_uv2[i];
        }
        for (int i = 0; i < 12; i +=2)
        {
            vertices_uv[i] = xOffset + vertices_uv[i] * frameWidth;
        }

        // Aktualizacja danych UV w buforze VBO
        glBindBuffer(GL_ARRAY_BUFFER, idVBO_uv);
        glBufferData(GL_ARRAY_BUFFER, sizeof(vertices_uv), &vertices_uv[0], GL_STATIC_DRAW);

    // Rendering
    glBindVertexArray(idVAO);
    glDrawArrays(GL_TRIANGLES, 0, 6);
    glBindVertexArray(0);

    // Wylaczanie
    glUseProgram(0);

    glutSwapBuffers();
}

// ---------------------------------------
void Initialize()
{
    // Ustawienia maszyny OpenGL
    glEnable(GL_DEPTH_TEST);
    glClearColor(0.7f, 0.7f, 0.7f, 1.0f);

    // Potok
    idProgram = glCreateProgram();
    glAttachShader(idProgram, LoadShader(GL_VERTEX_SHADER, "vertex.glsl"));
    glAttachShader(idProgram, LoadShader(GL_FRAGMENT_SHADER, "fragment.glsl"));
    LinkAndValidateProgram(idProgram);

    // VAO
    glGenVertexArrays(1, &idVAO);
    glBindVertexArray(idVAO);

    // Bufor na wspolrzedne wierzcholkow
    glGenBuffers(1, &idVBO_coord);
    glBindBuffer(GL_ARRAY_BUFFER, idVBO_coord);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices_coord), &vertices_coord[0], GL_STATIC_DRAW);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, NULL);
    glEnableVertexAttribArray(0);

    // Bufor na kolory
    glGenBuffers(1, &idVBO_color);
    glBindBuffer(GL_ARRAY_BUFFER, idVBO_color);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices_color), &vertices_color[0], GL_STATIC_DRAW);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 0, NULL);
    glEnableVertexAttribArray(1);

    // Bufor na wspolrzedne tekstury
    glGenBuffers(1, &idVBO_uv);
    glBindBuffer(GL_ARRAY_BUFFER, idVBO_uv);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices_uv), &vertices_uv[0], GL_STATIC_DRAW);
    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 0, NULL);
    glEnableVertexAttribArray(2);

    glBindVertexArray(0);

    // Wczytanie pliku tekstury
    int tex_width, tex_height, tex_n;
    unsigned char *tex_data;

    // tylko raz w calym programie
    stbi_set_flip_vertically_on_load(true);
    glPixelStorei(GL_UNPACK_ALIGNMENT, 1);

    // wczytywanie pliku graficznego
    tex_data = stbi_load("sprite.png", &tex_width, &tex_height, &tex_n, 0);
    if (tex_data == NULL)
    {
        printf("Image can't be loaded!\n");
        exit(1);
    }

    // Utworzenie obiektu tekstury
    glGenTextures(1, &idTexture);
    glBindTexture(GL_TEXTURE_2D, idTexture);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, tex_width, tex_height, 0, GL_RGB, GL_UNSIGNED_BYTE, tex_data);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
}

// ---------------------------------------
void Reshape(int width, int height)
{
    glViewport(0, 0, width, height);
    matProj = glm::perspective(glm::radians(80.0f), width / (float)height, 0.1f, 50.0f);
}

// --------------------------------------------------------------
void Keyboard(unsigned char key, int x, int y)
{
    switch (key)
    {
    case 27: // ESC key
        glutLeaveMainLoop();
        break;
    }
}

// ---------------------------------------------------
int main(int argc, char *argv[])
{
    // GLUT
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitContextVersion(3, 2);
    glutInitContextProfile(GLUT_CORE_PROFILE);
    glutInitWindowSize(500, 500);
    glutCreateWindow("Programownie grafiki w OpenGL");

    glutDisplayFunc(DisplayScene);
    glutReshapeFunc(Reshape);
    glutMouseFunc(MouseButton);
    glutMotionFunc(MouseMotion);
    glutMouseWheelFunc(MouseWheel);
    glutKeyboardFunc(Keyboard);
    glutSpecialFunc(SpecialKeys);

    // GLEW
    glewExperimental = GL_TRUE;
    GLenum err = glewInit();
    if (GLEW_OK != err)
    {
        printf("GLEW Error\n");
        exit(1);
    }

    // OpenGL
    if (!GLEW_VERSION_3_2)
    {
        printf("Brak OpenGL 3.2!\n");
        exit(1);
    }

    Initialize();
    glutTimerFunc( 1000/20 ,Animation,0);
    glutMainLoop();

    // Cleaning
    glDeleteProgram(idProgram);
    glDeleteVertexArrays(1, &idVBO_coord);
    glDeleteVertexArrays(1, &idVBO_color);
    glDeleteVertexArrays(1, &idVBO_uv);
    glDeleteVertexArrays(1, &idVAO);
    glDeleteTextures(1, &idTexture);

    return 0;
}
