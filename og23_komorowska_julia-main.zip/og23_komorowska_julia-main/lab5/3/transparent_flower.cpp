#include <stdio.h>
#include <GL/glew.h>
#include <GL/freeglut.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <vector>

// Lokalne pliki nagłówkowe
#include "utilities.hpp"

// Biblioteka do obsługi plików graficznych
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

// Macierze transformacji i rzutowania
glm::mat4 matProj = glm::mat4(1.0);
glm::mat4 matView = glm::mat4(1.0);

// Identyfikatory obiektów
GLuint idProgram;
GLuint idVAO;
GLuint idVBO_coord;
GLuint idVBO_uv;
GLuint idTexture;

// Współrzędne kwadratu
GLfloat vertices[12 * 3] = {
    -1.000000, -1.000000, 0.000000,
    1.000000, 1.000000, 0.000000,
    1.000000, -1.000000, 0.000000,
    -1.000000, -1.000000, 0.000000,
    -1.000000, 1.000000, 0.000000,
    1.000000, 1.000000, 0.000000,

    0.000000, -1.000000, 1.000000,
    0.000000, 1.000000, -1.000000,
    0.000000, -1.000000, -1.000000,
    0.000000, -1.000000, 1.000000,
    0.000000, 1.000000, 1.000000,
    0.000000, 1.000000, -1.000000,
};

// Współrzędne UV kwadratu
GLfloat uvs[12 * 2] = {
    0.000000, 0.000000,
    0.98, 0.98,
    0.98, 0.000000,
    0.000000, 0.000000,
    0.000000, 0.98,
    0.98, 0.98,

    0.98, 0.000000,
    0.000000, 0.98,
    0.000000, 0.000000,
    0.98, 0.000000,
    0.98, 0.98,
    0.000000, 0.98,
};

// Wektor macierzy modelu
std::vector<glm::mat4> modelMatrices;

void DisplayScene()
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    matView = UpdateViewMatrix();

    glUseProgram(idProgram);

    glUniformMatrix4fv(glGetUniformLocation(idProgram, "matProj"), 1, GL_FALSE, glm::value_ptr(matProj));
    glUniformMatrix4fv(glGetUniformLocation(idProgram, "matView"), 1, GL_FALSE, glm::value_ptr(matView));

    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, idTexture);
    glUniform1i(glGetUniformLocation(idProgram, "tex"), 0);

    glBindVertexArray(idVAO);

    for (const auto &model : modelMatrices)
    {
        glUniformMatrix4fv(glGetUniformLocation(idProgram, "matModel"), 1, GL_FALSE, glm::value_ptr(model));
        glDrawArrays(GL_TRIANGLES, 0, 12);
    }

    glBindVertexArray(0);

    glUseProgram(0);

    glutSwapBuffers();
}
float random_between_two_float(float min, float max)
{
    return (min + 1) + (((float) rand()) / (float) RAND_MAX) * (max - (min + 1));
}
void InitializeModels()
{
        srand(time(NULL));
    for (int i = 0; i < 10; ++i)
    {
        glm::mat4 model = glm::mat4(1.0);
        model = glm::translate(model, glm::vec3(i * 2.0,random_between_two_float(-2.0,2.0), 0.0)); // Przesunięcie w osi X
        modelMatrices.push_back(model);
    }
}

void Initialize()
{
    	matView = glm::mat4(1.0);
	matView = glm::translate( matView, glm::vec3(0, 0, -4) );
    glEnable(GL_DEPTH_TEST);
    glClearColor(0.7f, 0.7f, 0.7f, 1.0f);

    idProgram = glCreateProgram();
    glAttachShader(idProgram, LoadShader(GL_VERTEX_SHADER, "vertex.glsl"));
    glAttachShader(idProgram, LoadShader(GL_FRAGMENT_SHADER, "fragment.glsl"));
    LinkAndValidateProgram(idProgram);

    glGenVertexArrays(1, &idVAO);
    glBindVertexArray(idVAO);

    glGenBuffers(1, &idVBO_coord);
    glBindBuffer(GL_ARRAY_BUFFER, idVBO_coord);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, NULL);
    glEnableVertexAttribArray(0);

    glGenBuffers(1, &idVBO_uv);
    glBindBuffer(GL_ARRAY_BUFFER, idVBO_uv);
    glBufferData(GL_ARRAY_BUFFER, sizeof(uvs), uvs, GL_STATIC_DRAW);
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 0, NULL);
    glEnableVertexAttribArray(1);

    glBindVertexArray(0);

    stbi_set_flip_vertically_on_load(true);

    int tex_width, tex_height, tex_n;
    unsigned char *tex_data;

    tex_data = stbi_load("flower32bit.png", &tex_width, &tex_height, &tex_n, 0);

    if (tex_data == NULL)
    {
        printf("Image can’t be loaded!\n");
        exit(1);
    }

    glGenTextures(1, &idTexture);
    glBindTexture(GL_TEXTURE_2D, idTexture);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, tex_width, tex_height, 0, GL_RGBA, GL_UNSIGNED_BYTE, tex_data);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);

    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
}

void Reshape(int width, int height)
{
    glViewport(0, 0, width, height);
    matProj = glm::perspective(glm::radians(80.0f), width / (float)height, 0.1f, 50.0f);
}

void Keyboard(unsigned char key, int x, int y)
{
    switch (key)
    {
    case 27:
        glutLeaveMainLoop();
        break;
    }
}

int main(int argc, char *argv[])
{
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitContextVersion(3, 2);
    glutInitContextProfile(GLUT_CORE_PROFILE);
    glutInitWindowSize(800, 600);
    glutCreateWindow("OpenGL 3D Programming");

    glutDisplayFunc(DisplayScene);
    glutReshapeFunc(Reshape);
    glutKeyboardFunc(Keyboard);

    glewExperimental = GL_TRUE;
    GLenum err = glewInit();
    if (GLEW_OK != err)
    {
        printf("GLEW Error\n");
        exit(1);
    }

    if (!GLEW_VERSION_3_2)
    {
        printf("Brak OpenGL 3.2!\n");
        exit(1);
    }

    Initialize();
    InitializeModels();

    glutMainLoop();

    glDeleteProgram(idProgram);
    glDeleteVertexArrays(1, &idVBO_coord);
    glDeleteVertexArrays(1, &idVBO_uv);
    glDeleteTextures(1, &idTexture);

    return 0;
}
