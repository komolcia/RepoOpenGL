# lab5
## 1
![img.png](../screeny/img_7.png)
## 2
![img_1.png](../screeny/img_8.png) 
## 3
![img_1.png](../screeny/img_9.png) 
## 4
![img_1.png](../screeny/img_12.png) 