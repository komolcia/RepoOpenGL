#include <stdio.h>
#include <GL/glew.h>
#include <GL/freeglut.h>
#include <vector>

#include "shader_stuff.h"
#include "utilities.hpp"
// ---------------------------------------
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include "obj_loader.hpp"
#include <stdio.h>
#include <GL/glew.h>
#include <GL/freeglut.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

// Lokalne pliki naglowkowe
#include "utilities.hpp"

// -----------------------------------------
// NOWE: plik do obslugi plikow graficznych
// -----------------------------------------
# define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

// ---------------------------------------
// Identyfikatory obiektow
GLuint idProgram;	// programu
GLuint idVAO;		// tablic wierzcholkow
GLuint idVBO_coord;	// bufor wspolrzednych
GLuint idVBO_color; // bufor na kolory

GLuint idVAO2;		// tablic wierzcholkow
GLuint idVBO_coord2;	// bufor wspolrzednych
GLuint idVBO_color2; // bufor na kolory

GLuint idVAO3;		// tablic wierzcholkow
GLuint idVBO_coord3;	// bufor wspolrzednych
GLuint idVBO_color3; // bufor na kolory


GLuint idVAO4;		// tablic wierzcholkow
GLuint idVBO_coord4;	// bufor wspolrzednych
GLuint idVBO_color4; // bufor na kolory

GLuint idVAO5;		// tablic wierzcholkow
GLuint idVBO_coord5;	// bufor wspolrzednych
GLuint idVBO_color5; // bufor na kolory
GLuint idTexture;
// ---------------------------------------
// Dane szescianu
#include "cube.h"

// Zmienne do obracania szescianem
GLfloat angleX = 0.0f;
GLfloat angleY = 0.0f;
GLfloat angleX_B = 0.0f;
GLfloat angleY_B = 0.0f;

glm::mat4 matProj;
glm::mat4 matView;

glm::mat4 matModel1;
glm::mat4 matModel2;
glm::mat4 matModel3;
glm::mat4 matModel4;

std::vector<glm::vec3> vert,vert2,vert3,vert4,vert5;
std::vector<glm::vec2> texture,texture2,texture3,texture4,texture5;
std::vector<glm::vec3> normals,normals2,normals3,normals4,normals5;




// ---------------------------------------
void DisplayScene()
{
	// Czyszczenie bufora koloru
	glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );


	// Wlaczenie programu
	glUseProgram( idProgram );

		glUniformMatrix4fv( glGetUniformLocation(idProgram, "matProj"), 1, GL_FALSE, glm::value_ptr(matProj) );
		glUniformMatrix4fv( glGetUniformLocation(idProgram, "matView"), 1, GL_FALSE, glm::value_ptr(matView) );

  // Update rotation angles for animation
    angleX += 0.5f; // Adjust the speed of rotation
    angleY += 0.5f;
    angleX_B += 0.5f;
    angleY_B += 0.5f;


    // Obiekt B
    matModel2 = glm::mat4(1.0);
    matModel2 = glm::translate(matModel2, glm::vec3(0, 0, 0));
    matModel2 = glm::rotate(matModel2, glm::radians(angleX_B), glm::vec3(1, 0, 0));
    matModel2 = glm::rotate(matModel2, glm::radians(angleY_B), glm::vec3(0, 1, 0));

    glUniformMatrix4fv(glGetUniformLocation(idProgram, "matModel"), 1, GL_FALSE, glm::value_ptr(matModel2));

        glActiveTexture(GL_TEXTURE0);
    glBindVertexArray(idVAO3);
    glBindTexture(GL_TEXTURE_2D, idTexture);
    glDrawArrays(GL_TRIANGLES, 0, vert3.size());
    glBindVertexArray(0);

        glUniform1i(glGetUniformLocation(idProgram, "tex"), 0);


	// Wylaczanie
	glUseProgram( 0 );


	glutSwapBuffers();
}

// ---------------------------------------
void Initialize()
{
    	// Macierze kontrolujace polozenie kamery
	matView = glm::mat4(1.0);
	matView = glm::translate( matView, glm::vec3(0, 0, -2) );
	// Wczytujemy plik obj
 if (!loadOBJ("truskawka.obj", vert, texture, normals) ||
        !loadOBJ("monkey.obj", vert2, texture2, normals2) ||
        !loadOBJ("truskawka.obj", vert3, texture3, normals3) ||
        !loadOBJ("models/sphere.obj", vert4, texture4, normals4) ||
     !loadOBJ("ground.obj", vert5, texture5, normals5))
    {
		printf("Nie wczytano pliku obj!\n");
	}



	// 0. Ustawienie maszyny stanów OpenGL

	// Ustawianie domyslnego koloru, ktorym bedzie
	// czyszczony bufor koloru
	glClearColor( 0.5f, 0.5f, 0.5f, 1.0f );


	// Wlaczanie testu glebokosci
	glEnable(GL_DEPTH_TEST);
	glDepthFunc( GL_LESS );


	// 1. Potok
	idProgram = glCreateProgram();
	glAttachShader( idProgram, LoadShader(GL_VERTEX_SHADER, "vertex.glsl"));
	glAttachShader( idProgram, LoadShader(GL_FRAGMENT_SHADER, "fragment.glsl"));
	LinkAndValidateProgram( idProgram );


	// 2. VAO





    glGenVertexArrays( 1, &idVAO3 );
	glBindVertexArray( idVAO3 );
		// Bufor na wspolrzedne wierzcholkow
		glGenBuffers( 1, &idVBO_coord3 );
		glBindBuffer( GL_ARRAY_BUFFER, idVBO_coord3 );
		glBufferData( GL_ARRAY_BUFFER, vert3.size() * sizeof(glm::vec3), &vert3[0], GL_STATIC_DRAW );
		glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, NULL);
		glEnableVertexAttribArray( 0 );
		// Bufor na kolory wierzcholkow
		glGenBuffers( 1, &idVBO_color3 );
		glBindBuffer( GL_ARRAY_BUFFER, idVBO_color3 );
		glBufferData( GL_ARRAY_BUFFER, 4000 * sizeof(glm::vec3), &normals3[0], GL_STATIC_DRAW );
		glVertexAttribPointer( 1, 3, GL_FLOAT, GL_FALSE, 0, NULL );
		glEnableVertexAttribArray( 1 );
	glBindVertexArray( 0 );








	// ------------------------------------
	// NOWE: Wczytanie pliku tekstury
	// ------------------------------------

	int tex_width, tex_height, tex_n,tex_width2, tex_height2, tex_n2,tex_width3, tex_height3, tex_n3;
	unsigned char *tex_data1,*tex_data2,*tex_data3;

	// tylko raz w calym programie
	stbi_set_flip_vertically_on_load(true);
	glPixelStorei(GL_UNPACK_ALIGNMENT, 1);

	// wczytywanie pliku graficznego
	tex_data1 = stbi_load ("cube.png", &tex_width , &tex_height , &tex_n, 0);
	if ( tex_data1 == NULL) {
		printf ("Image can�t be loaded!\n");
	}

	// ------------------------------------
	// NOWE: Utworzenie obiektu tekstury
	// ------------------------------------

	glGenTextures(1, &idTexture);
	glBindTexture(GL_TEXTURE_2D, idTexture);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, tex_width, tex_height, 0, GL_RGB, GL_UNSIGNED_BYTE, tex_data1);
 glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glGenerateMipmap(GL_TEXTURE_2D);
	glEnable(GL_TEXTURE_2D);



}

// ---------------------------------------
void Reshape( int width, int height )
{
	glViewport( 0, 0, width, height );
	matProj = glm::perspective(3.14/3, (double)width/(double)height, 0.1, 10.0);

}

// ---------------------------------------------------
void Keyboard(unsigned char key, int x, int y)
{
    switch (key)
    {
    case 27:
        exit(0);
        break;

    }

    glutPostRedisplay();
}
void Timer(int value)
{
    glutPostRedisplay();
    glutTimerFunc(16, Timer, 0);  // 60 frames per second (1000ms/60 ≈ 16.67ms)
}

// ---------------------------------------------------
int main( int argc, char *argv[] )
{
	// GLUT
	glutInit( &argc, argv );
	glutInitDisplayMode( GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH );
	glutInitContextVersion( 3, 2 );
	glutInitContextProfile( GLUT_CORE_PROFILE );
	glutInitWindowSize( 600, 400 );
	glutCreateWindow( "Sześcian" );


	glutDisplayFunc( DisplayScene );
	glutReshapeFunc( Reshape );
	glutKeyboardFunc( Keyboard );


 // Set up the timer
    glutTimerFunc(0, Timer, 0);

	// GLEW
	glewExperimental = GL_TRUE;
	GLenum err = glewInit();
	if( GLEW_OK != err )
	{
		printf("GLEW Error\n");
		exit(1);
	}

	// OpenGL
	if( !GLEW_VERSION_3_2 )
	{
		printf("Brak OpenGL 3.2!\n");
		exit(1);
	}


	Initialize();
	glutMainLoop();


	// Cleaning
	glDeleteProgram( idProgram );
	glDeleteVertexArrays( 1, &idVBO_coord );
	glDeleteVertexArrays( 1, &idVBO_color );
	glDeleteVertexArrays( 1, &idVAO );
    glDeleteVertexArrays( 1, &idVBO_coord2 );
	glDeleteVertexArrays( 1, &idVBO_color2 );
	glDeleteVertexArrays( 1, &idVAO2 );
    glDeleteVertexArrays( 1, &idVBO_coord3 );
    glDeleteVertexArrays( 1, &idVBO_color3 );
    glDeleteVertexArrays( 1, &idVAO3 );
    glDeleteVertexArrays( 1, &idVBO_coord4 );
    glDeleteVertexArrays( 1, &idVBO_color4 );
    glDeleteVertexArrays( 1, &idVAO4 );
    glDeleteVertexArrays( 1, &idVBO_coord5 );
    glDeleteVertexArrays( 1, &idVBO_color5 );
    glDeleteVertexArrays( 1, &idVAO5 );

	return 0;
}
