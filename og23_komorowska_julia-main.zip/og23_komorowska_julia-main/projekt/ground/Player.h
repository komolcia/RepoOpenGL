#ifndef __CPLAYER
#define __CPLAYER
class Player;
// ----------------------------------------------------------------
// Klasa do reprezentacji obiektu, ktory porusza sie po scenie
class CPlayer
{

public:

    // skladowe
    glm::vec3 Position = glm::vec3(0.0, -3.0, 0.0);
    glm::vec3 Direction = glm::vec3(1.0, 0.0, 0.0);
    float Angle = 0.0;

    glm::vec3 matModelCubeTab2[10]= {glm::vec3(0.0, -3.0, 0.0),glm::vec3(0.0, -3.0, 0.0),glm::vec3(0.0, -3.0, 0.0),glm::vec3(0.0, -3.0, 0.0),glm::vec3(0.0, -3.0, 0.0),glm::vec3(0.0, -3.0, 0.0),glm::vec3(0.0, -3.0, 0.0),glm::vec3(0.0, -3.0, 0.0),glm::vec3(0.0, -3.0, 0.0),glm::vec3(0.0, -3.0, 0.0)};
    bool eaten[10]= {false,false,false,false,false,false,false,false,false,false};
    // macierz modelu
    glm::mat4 matModel = glm::mat4(1.0);


    CPlayer() { }

    // Inicjalizacja obiektu
    void Init()
    {
        // TO_DO: Uzupelnij wedle uznania
    }

    // Obliczenie wysokosci nad ziemia
    void UpdateLatitute(CGround myGround)
    {
        Position.y=myGround.getAltitute( glm::vec2(Position.x, Position.z ));
        matModel = glm::translate(glm::mat4(1.0), glm::vec3(Position.x,Position.y,Position.z));
    }


    // aktualizacja macierzy modelu
    void UpdateMatModel()
    {
        matModel = glm::rotate(matModel, Angle, glm::vec3(0.0, 1.0, 0.0));
    }

    // ustawienie pozycji na scenie
    void SetPosition(glm::vec3 pos)
    {
        Position = pos;

        UpdateMatModel();
    }

    // zmiana pozycji na scenie
    void Move(float val,CGround myGround)
    {
        glm::vec3 OldPosition = Position;
        Position += Direction * val;


        for(int i=0; i<6; i++)
        {
            if(i%2==0)
            {
                if(isCollision(glm::vec3(i+i*i, myGround.getAltitute( glm::vec2(i+i*i, i+i*i )), i+i*i)))
                {
                    Position=OldPosition;
                    return;
                }
            }
            else
            {
                if(isCollision(glm::vec3(i-i*i,myGround.getAltitute( glm::vec2(i-i*i, i-i*i )), i-i*i)))
                {
                    Position=OldPosition;

                    return;
                }

            }
        }
        if(isCollision(glm::vec3(-4.0, 1.0, -3.0)) || isCollision(glm::vec3(0.0, 0.2, 0.0)) )
        {
            OldPosition=Position;
            return;
        }
        else
        {
            for(int i=0; i<10; i++)
            {
                if(isCollisionBone(matModelCubeTab2[i]) && eaten[i]==false)
                {
                    eaten[i]=true;
                }
            }

            // aktualizacja danych i macierzy
            UpdateLatitute(myGround);
            UpdateMatModel();
        }
    }

    bool isCollision(glm::vec3 objectPosition)
    {
        float distance = glm::distance(Position,objectPosition );
        if (distance < 0.5f + 0.5f)
        {
            printf("%f",distance);
            printf("Kolizja sfer");
            return true;
        }
        return false;
    }
    bool isCollisionBone(glm::vec3 objectPosition)
    {
        objectPosition.y=Position.y;
        float distance = glm::distance(Position,objectPosition );
        if (distance < 1.0f)
        {
            printf("Zjedzone");
            return true;
        }
        return false;
    }

    void Rotate(float angle,CGround myGround)
    {
        Angle += angle;
        Direction.x = cos(Angle);
        Direction.z = -sin(Angle);


        // aktualizacja
        UpdateLatitute(myGround);
        UpdateMatModel();
    }

};


#endif
