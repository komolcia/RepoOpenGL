#include <GL/glew.h>
#include <GL/freeglut.h>
#include <fstream>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <time.h>
#include <SOIL/SOIL.h>
#include <GL/glew.h>
#include <GL/freeglut.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <random>
#include <string>
using glm::vec3;
struct LightParam
{
    vec3 Ambient;
    vec3 Diffuse;
    vec3 Specular;
    vec3 Attenuation;
    vec3 Position;
};

struct LightParam redLight =
{
    vec3(0.2, 0.1, 0.1),   // ambient
    vec3(1.0, 0.0, 0.0),   // diffuse
    vec3(1.0, 0.0, 0.0),   // specular
    vec3(1.0, 0.0, 0.1),   // attenuation
    vec3(8.0, 3.0, 1.0)    // position

};

struct LightParam greenLight =
{
    vec3(0.1, 0.1, 0.1),   // ambient
    vec3(0.0, 1.0, 0.0),   // diffuse
    vec3(0.0, 1.0, 0.0),   // specular
    vec3(1.0, 0.0, 0.1),   // attenuation
    vec3(-4.0, 3.0, 1.0)   // position
};

struct LightParam blueLight =
{
    vec3(0.1, 0.1, 0.1),   // ambient
    vec3(0.0, 0.0, 1.0),   // diffuse
    vec3(0.0, 0.0, 1.0),   // specular
    vec3(1.0, 0.0, 0.1),   // attenuation
    vec3(6.0, 2.0, 4.0)   // position
};

struct MaterialParam
{
    vec3 Ambient;
    vec3 Diffuse;
    vec3 Specular;
    float Shininess;
};

struct MaterialParam myMaterial =
{
    vec3 (0.2, 0.2, 0.2),   // ambient
    vec3 (1.0, 1.0, 1.0),   // diffuse
    vec3 (1.5, 1.0, 1.0),   // specular
    1.0 // shininess
};

struct MaterialParam myMaterialMatte =
{
    vec3(0.2, 0.2, 0.2),   // ambient
    vec3(1.0, 1.0, 1.0),   // diffuse
    vec3(0.0, 0.0, 0.0),   // specular (set to zero for matte appearance)
    1.0                   // shininess (set to zero for matte appearance)
};

struct MaterialParam myMaterialShine =
{
    vec3 (0.2, 0.2, 0.2),   // ambient
    vec3 (1.0, 1.0, 1.0),   // diffuse (you might want to adjust this)
    vec3(2.0, 2.0, 2.0),   // specular (adjust as needed for shiny appearance)
    40.0                   // shininess (adjust as needed for shiny appearance)
};

struct LightParam myLight =
{
    vec3 (0.1, 0.1, 0.1),   // ambient
    vec3 (1.0, 1.0, 1.0),   // diffuse
    vec3 (1.0, 1.0, 1.0),   // specular
    vec3 (1.0, 0.0, 0.1),   // attenuation
    vec3 (2.0, 3.0, 1.0)    // position

};
void SentLightParameters()
{
    GLint idProgram = 0;
    glGetIntegerv(GL_CURRENT_PROGRAM, &idProgram);
       if (idProgram == 0) return;

    glUniform3fv(glGetUniformLocation(idProgram,"myLight.Ambient"), 1, glm::value_ptr(myLight.Ambient));
    glUniform3fv(glGetUniformLocation(idProgram,"myLight.Diffuse"), 1, glm::value_ptr(myLight.Diffuse));
    glUniform3fv(glGetUniformLocation(idProgram,"myLight.Specular"), 1, glm::value_ptr(myLight.Specular));
    glUniform3fv(glGetUniformLocation(idProgram,"myLight.Attenuation"), 1, glm::value_ptr(myLight.Attenuation));
    glUniform3fv(glGetUniformLocation(idProgram,"myLight.Position"), 1, glm::value_ptr(myLight.Position));

    glUniform3fv(glGetUniformLocation(idProgram,"redLight.Ambient"), 1, glm::value_ptr(redLight.Ambient));
    glUniform3fv(glGetUniformLocation(idProgram,"redLight.Diffuse"), 1, glm::value_ptr(redLight.Diffuse));
    glUniform3fv(glGetUniformLocation(idProgram,"redLight.Specular"), 1, glm::value_ptr(redLight.Specular));
    glUniform3fv(glGetUniformLocation(idProgram,"redLight.Attenuation"), 1, glm::value_ptr(redLight.Attenuation));
    glUniform3fv(glGetUniformLocation(idProgram,"redLight.Position"), 1, glm::value_ptr(redLight.Position));

    glUniform3fv(glGetUniformLocation(idProgram,"greenLight.Ambient"), 1, glm::value_ptr(greenLight.Ambient));
    glUniform3fv(glGetUniformLocation(idProgram,"greenLight.Diffuse"), 1, glm::value_ptr(greenLight.Diffuse));
    glUniform3fv(glGetUniformLocation(idProgram,"greenLight.Specular"), 1, glm::value_ptr(greenLight.Specular));
    glUniform3fv(glGetUniformLocation(idProgram,"greenLight.Attenuation"), 1, glm::value_ptr(greenLight.Attenuation));
    glUniform3fv(glGetUniformLocation(idProgram,"greenLight.Position"), 1, glm::value_ptr(greenLight.Position));

    glUniform3fv(glGetUniformLocation(idProgram,"blueLight.Ambient"), 1, glm::value_ptr(blueLight.Ambient));
    glUniform3fv(glGetUniformLocation(idProgram,"blueLight.Diffuse"), 1, glm::value_ptr(blueLight.Diffuse));
    glUniform3fv(glGetUniformLocation(idProgram,"blueLight.Specular"), 1, glm::value_ptr(blueLight.Specular));
    glUniform3fv(glGetUniformLocation(idProgram,"blueLight.Attenuation"), 1, glm::value_ptr(blueLight.Attenuation));
    glUniform3fv(glGetUniformLocation(idProgram,"blueLight.Position"), 1, glm::value_ptr(blueLight.Position));
};
void SentMaterialParameters()
{
    GLint idProgram = 0;
    glGetIntegerv(GL_CURRENT_PROGRAM, &idProgram);

    glUniform3fv(glGetUniformLocation(idProgram,"myMaterial.Ambient"), 1, glm::value_ptr(myMaterial.Ambient));
    glUniform3fv(glGetUniformLocation(idProgram,"myMaterial.Diffuse"), 1, glm::value_ptr(myMaterial.Diffuse));
    glUniform3fv(glGetUniformLocation(idProgram,"myMaterial.Specular"), 1, glm::value_ptr(myMaterial.Specular));
    glUniform1f(glGetUniformLocation(idProgram,"myMaterial.Shininess"), myMaterial.Shininess);

};

struct Texture
{
    GLuint id;       // Identyfikator tekstury
    int width;       // Szerokość tekstury
    int height;      // Wysokość tekstury
    unsigned char* image;  // Obraz tekstury
};

struct Material
{
    Texture texture;  // Tekstura materiału
};
