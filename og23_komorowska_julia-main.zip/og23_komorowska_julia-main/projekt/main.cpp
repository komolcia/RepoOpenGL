#include <stdio.h>
#include <GL/glew.h>
#include <GL/freeglut.h>
#include <fstream>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <time.h>
#include <SOIL/SOIL.h>
#include <GL/glew.h>
#include <GL/freeglut.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <random>
#include <string>
# define STB_IMAGE_IMPLEMENTATION
#include "obj_loader.hpp"
#include "light.hpp"
#include "shadow_dir.hpp"
#include "shadow_point.hpp"
#include "skybox/skybox.hpp"
#include "mesh.hpp"
#include "frame.hpp"
#include "ground/Ground.h"
#include "ground/Player.h"
#include "ground/Camera.h"
// ---------------------------------------
// NOWE: funkcje do obslugi tekstu
#include "text/text-ft.hpp"
// ---------------------------------------

CGround myGround;
CPlayer myPlayer;
CFPSCamera myCamera;

using glm::vec3;
CProgram mainProgram, graveProgram, ghostProgram, cubeProgram,sphereProgram,ravenProgram,squareProgram,postProgram;
CMesh grave3D, ground3D, ghost3D, cube3D,sphere3D,raven3D;


int matModelCubeInit()
{
    // Initialize the array of translation matrices

    float startX = -10.0f;
    float endX = 10.0f;
    float stepX = (endX - startX) / 9.0f; // Adjust the step size for even distribution
    float y = 1.0f;
    float z = -4.0f;
    // Generate the translation matrices and store them in the array
    for (int i = 0; i < 10; ++i)
    {
        float currentX = startX + i * stepX;
        float currentZ = z + 5.0f * std::sin(currentX);
        matModelCubeTab[i] = glm::translate(glm::mat4(1.0f), glm::vec3(startX + i * stepX, myGround.getAltitute(glm::vec2(startX + i * stepX,z))+4.0, currentZ));
    }

    // Print the resulting matrices

    return 0;
}

float random_between_two_float(float min, float max)
{
    return (min + 1) + (((float) rand()) / (float) RAND_MAX) * (max - (min + 1));
}
void RenderGraves(glm::mat4x4 matViewMy)
{

    matModelGrave = glm::translate(matModel, glm::vec3(0.0, 0.2, 0.0));

    for(int i=0; i<6; i++)
    {
        if(i%2==0)
        {
            matModelGrave = glm::translate(matModel, glm::vec3(i+i*i, myGround.getAltitute( glm::vec2(i+i*i, i+i*i )), i+i*i));
        }
        else
        {
            matModelGrave = glm::translate(matModel, glm::vec3(i-i*i,myGround.getAltitute( glm::vec2(i-i*i, i-i*i )), i-i*i));

        }

        graveProgram.Use();
        shadowPointLight.SendUniforms(graveProgram.idProgram, 9, cameraPos,randomLights);
        graveProgram.SetMVP(matViewMy,matProj,true,false);
        glActiveTexture(GL_TEXTURE1);
        glBindTexture(GL_TEXTURE_2D, grave3D.material.texture.id);
        graveProgram.SendInt( "textureSampler", 1);
        glActiveTexture(GL_TEXTURE2);
        glBindTexture(GL_TEXTURE_2D, DepthMap_idTexture);
        graveProgram.SendInt("tex_shadowMap", 2);
        graveProgram.SendInt( "useLight", useLight);
        graveProgram.SendInt( "tex_skybox", 7);
        graveProgram.SendInt("useShadowMapping",useShadowMapping);
        graveProgram.SendInt("useShadowCubeMapping",useShadowCubeMapping);

        graveProgram.SendInt( "isGhost", false);
        SendLightParameters(graveProgram.idProgram);
        graveProgram.SendMaterial(myMaterialShine);
        grave3D.Draw(matModelGrave);
        glUseProgram( 0 );
    }


}
void RenderCube(glm::mat4x4 matViewMy)
{
    for(int i =0; i<10; i++)
    {
        if(!myPlayer.eaten[i])
        {
            matModelCube = glm::mat4(1.0);
            matModelCube=matModelCubeTab[i];
            matModelCube = glm::rotate(matModelCube, angleXCube, glm::vec3(1.0, 0.0, 0.0));
            matModelCube = glm::rotate(matModelCube, angleYCube, glm::vec3(0.0, 1.0, 0.0));
            cubeProgram.Use();
            shadowPointLight.SendUniforms(cubeProgram.idProgram, 9, cameraPos,randomLights);
            cubeProgram.SendFloat("angleXCube", angleXCube);
            cubeProgram.SendFloat("angleYCube", angleYCube);
            cubeProgram.SetMVP(matViewMy,matProj,true,false);
            glActiveTexture(GL_TEXTURE4);
            glBindTexture(GL_TEXTURE_2D, cube3D.material.texture.id);
            cubeProgram.SendInt("textureSampler", 4);
            glActiveTexture(GL_TEXTURE2);
            glBindTexture(GL_TEXTURE_2D, DepthMap_idTexture);
            cubeProgram.SendInt( "tex_shadowMap", 2);
            cubeProgram.SendInt( "useLight", useLight);
            cubeProgram.SendInt( "tex_skybox", 7);
            cubeProgram.SendInt("useShadowMapping",useShadowMapping);
            cubeProgram.SendInt("useShadowCubeMapping",useShadowCubeMapping);

            cubeProgram.SendInt("isReflectOn", isReflectOn);
            cubeProgram.SendInt("isGhost", true);
            SendLightParameters(cubeProgram.idProgram);

            cubeProgram.SendMaterial(myMaterialMatte);
            cube3D.Draw(matModelCube);
            glUseProgram( 0 );
        }
    }

}
glm::vec3 generateRandomPlaceOfLight()
{
    return glm::vec3(random_between_two_float(0.0,10.0), random_between_two_float(0.0,10.0), random_between_two_float(0.0,10.0));
}
void Animation ()
{
    Time+=0.1f;
    clock_t now_T = clock ();
    double delta_T = now_T - last_T ;
    if( delta_T > 6)
    {
        if(height<4.0f && heightBool)
        {
            height += 0.01f;
        }
        else
        {
            heightBool=false;
            height -= 0.01f;
            if(height < 3.0f)
            {
                heightBool= true;
            }
        }
        angleXCube += 0.001f;
        angleYCube += 0.005f;
        glutPostRedisplay ();
        last_T = now_T ;
    }
    if(animatePoint)
    {
        lightPositionX += lightMovementSpeed;
        if (lightPositionX > 5.0f || lightPositionX < -5.0f)
        {
            lightMovementSpeed = -lightMovementSpeed;
        }
    }

}
void Menu(int value)
{
    srand(time(NULL));
    switch (value)
    {
    case 1:
        isDirectionalLight=false;
        useLight=true;
        animatePoint=false;
        point = false;
        usePhongReflect=false;
        showPointLightSpheres = false;
        useBlinnPhong = true;
        postprocessing=false;
        splotEffect=false;
        funEffect=false;
        useShadowMapping=false;
        useShadowCubeMapping = false;

        myLight = LightParam
        {
            vec3(0.1, 0.1, 0.1), // ambient
            vec3(1.0, 0.0, 0.0), // diffuse
            vec3(1.0, 0.0, 0.0), // specular
            vec3(1.0, 0.0, 0.1), // attenuation
            vec3(2.0, 3.0, 1.0)  // position
        };
        break;

    case 2:
        useBlinnPhong = false;
        usePhongReflect=true;
        isDirectionalLight=false;
        showPointLightSpheres = false;
        useLight=true;
        point = false;
        animatePoint=false;
        postprocessing=false;
        splotEffect=false;
        funEffect=false;
        useShadowMapping=false;
        useShadowCubeMapping = false;


        myLight = LightParam
        {
            vec3(0.1, 0.1, 0.1), // ambient
            vec3(1.0, 1.0, 1.0), // diffuse
            vec3(1.0, 1.0, 1.0), // specular
            vec3(1.0, 0.0, 0.1), // attenuation
            vec3(2.0, 3.0, 1.0)  // position
        };
        break;
    case 3:
        useLight=true;
        useBlinnPhong = false;
        animatePoint=true;
        showPointLightSpheres = true;
        point=true;
        usePhongReflect=false;
        isDirectionalLight=false;
        postprocessing=false;
        splotEffect=false;
        funEffect=false;
        useShadowMapping=false;
        useShadowCubeMapping = false;


        myLight = LightParam
        {

            vec3 (0.1, 0.1, 0.1),   // ambient
            vec3 (1.0, 1.0, 1.0),   // diffuse
            vec3 (1.0, 1.0, 1.0),   // specular
            vec3 (1.0, 0.0, 0.0),   // attenuation
            vec3 (2.0, 1.0, 1.0)    // position

        };
        break;

    case 4:
        isDirectionalLight=false;
        useBlinnPhong = false;
        usePhongReflect=false;
        showPointLightSpheres = false;
        point = false;
        animatePoint=false;
        useLight =false;
        postprocessing=false;
        splotEffect=false;
        funEffect=false;
        useShadowMapping=false;
        useShadowCubeMapping = false;



        break;
    case 5:
        useLight=true;
        useBlinnPhong = false;
        usePhongReflect=false;
        showPointLightSpheres = false;
        point=false;
        animatePoint=false;
        isDirectionalLight=true;
        postprocessing=false;
        splotEffect=false;
        funEffect=false;
        useShadowMapping=false;
        useShadowCubeMapping = false;


        myLight = LightParam
        {
            vec3 (0.1, 0.1, 0.1),   // ambient
            vec3 (1.0, 1.0, 1.0),   // diffuse
            vec3 (1.0, 1.0, 1.0),   // specular
            vec3 (1.0, 0.0, 0.1),   // attenuation// attenuation (reduce attenuation)
            vec3(2.0, 3.0, 1.0)       // position
        };
        break;
    case 6:
        useLight=true;
        animatePoint=false;
        useBlinnPhong = false;
        usePhongReflect=false;
        showPointLightSpheres = true;
        point=true;
        isDirectionalLight=false;
        postprocessing=false;
        splotEffect=false;
        funEffect=false;
        useShadowMapping=false;
        useShadowCubeMapping = false;

        myLight = LightParam
        {

            vec3 (0.1, 0.1, 0.1),   // ambient
            vec3 (1.0, 1.0, 1.0),   // diffuse
            vec3 (1.0, 1.0, 1.0),   // specular
            vec3 (1.0, 0.0, 0.0),   // attenuation
            vec3 (2.0, 1.0, 1.0)    // position

        };
        break;
    case 7:
        useLight=false;
        changeSkybox = !changeSkybox;
        postprocessing=false;
        splotEffect=false;
        funEffect=false;
        useShadowMapping=false;
        useShadowCubeMapping = false;
        break;
    case 8:
        useLight=false;
        isReflectOn=!isReflectOn;
        postprocessing=false;
        splotEffect=false;
        funEffect=false;
        useShadowMapping=false;
        useShadowCubeMapping = false;


        break;
    case 9:

        showMinimap=!showMinimap;
        postprocessing=false;
        splotEffect=false;
        funEffect=false;
        useShadowMapping=false;
        useShadowCubeMapping = false;


        break;
    case 10:
        postprocessing=true;
        showMinimap=false;
        splotEffect=true;
        funEffect=false;
        useShadowMapping=false;
        useShadowCubeMapping = false;

        break;
    case 11:
        showMinimap=false;
        postprocessing=true;
        funEffect = true;
        splotEffect=false;
        useShadowMapping=false;
        useShadowCubeMapping = false;

        break;
    case 12:
        useLight=true;
        animatePoint=false;
        useBlinnPhong = false;
        usePhongReflect=false;
        showPointLightSpheres = false;
        point=false;
        isDirectionalLight=false;
        postprocessing=false;
        splotEffect=false;
        funEffect=false;
        useShadowMapping=true;
        useShadowCubeMapping = false;

        break;
    case 13:
        useShadowCubeMapping = true;
        useLight=true;
        animatePoint=false;
        useBlinnPhong = false;
        usePhongReflect=false;
        showPointLightSpheres = false;
        point=false;
        isDirectionalLight=false;
        postprocessing=false;
        splotEffect=false;
        funEffect=false;
        useShadowMapping=false;
        randomLight = generateRandomPlaceOfLight();
        randomLights[0] = randomLight;
        break;

    }
    glutPostRedisplay();
}
void RenderScene_to_ShadowCubeMap()
{
    matView=myCamera.matView;

    // -------------------------------------------------------
    // NOWE: Generowanie szesciennej mapy cieni
    // -------------------------------------------------------
    glm::vec3 cameraPos = ExtractCameraPos(matView);
    // Uruchomienie programu do generowania mapy cieni
    // Przeslanie wszystkich potrzebnych informacji do shaderow
    // Ukrywamy to wszystko w metodzie GenBegin()
    // To ona ma wiedziec co robic

    // Renderowanie 6 razy do kazdej sciany cube mapy
    // Gdy poznamy shader geometrii, ten etap zostanie zamieniony
    // na jedno przejscie
    for (int face=0; face < 6; face++)
    {
        shadowPointLight.GenBegin(face);


        // Renderujemy obiekt przy uzyciu aktualnego programu
        glUniformMatrix4fv( glGetUniformLocation( shadowPointLight.idProgram, "matModel" ), 1, GL_FALSE, glm::value_ptr(matModel) );
        myCamera.SendPV(shadowPointLight.idProgram,"matProj","matView");


        matModel = glm::mat4(1.0);
        matModel = glm::rotate(matModel, 0.0f, glm::vec3(1.0, 0.0, 0.0));
        matModel = glm::rotate(matModel, 0.0f, glm::vec3(0.0, 1.0, 0.0));
        matModel = glm::translate(matModel, glm::vec3(0.0, 0.0, 0.0));
        matModelGrave = glm::translate(matModel, glm::vec3(0.0, 0.2, 0.0));

        matModelGhost = glm::translate(matModel, glm::vec3(0.0, height, 0.0));
        matModelCube = glm::mat4(1.0);
        matModelCube = glm::translate(matModel, glm::vec3(-4.0, 1.0, -3.0));
        matModelCube = glm::rotate(matModelCube, angleXCube, glm::vec3(1.0, 0.0, 0.0));
        matModelCube = glm::rotate(matModelCube, angleYCube, glm::vec3(0.0, 1.0, 0.0));

        matModelRaven = glm::mat4(1.0);
        matModelRaven = glm::translate(matModel, glm::vec3(-6.0, 1.0, -4.0));
        matModelRaven = glm::rotate(matModelRaven, angleXCube, glm::vec3(1.0, 0.0, 0.0));
        matModelRaven = glm::rotate(matModelRaven, angleYCube, glm::vec3(0.0, 1.0, 0.0));
        ground3D.Draw(matModel);

        for(int i=0; i<6; i++)
        {
            if(i%2==0)
            {
                matModelCube = glm::translate(matModel, glm::vec3(2*i+i*i-3.0, myGround.getAltitute( glm::vec2(2*i+i*i-3.0, 2*i+i*i-3.0 ))+1.0, 2*i+i*i-3.0));
                grave3D.Draw(matModelGrave);
            }
            else
            {
                matModelGrave = glm::translate(matModel, glm::vec3(i-i*i,myGround.getAltitute( glm::vec2(i-i*i, i-i*i )), i-i*i));
                grave3D.Draw(matModelGrave);

            }
        }
        ghost3D.Draw(matModelGhost);
        for(int i=0; i<10; i++)
        {
            if(!myPlayer.eaten[i])
            {
                matModelCube=matModelCubeTab[i];
                cube3D.Draw(matModelCube);
            }



        }
        raven3D.DrawMultiple(matModelRaven);
    }

    // Zakonczenie procesu generowania cieni
    shadowPointLight.GenEnd();
}
void RenderScene_to_ShadowMap()
{
    matView=myCamera.matView;

    glViewport(0, 0, DepthMap_Width, DepthMap_Height);
    glBindFramebuffer(GL_FRAMEBUFFER, DepthMap_idFrameBuffer);
    glClear(GL_DEPTH_BUFFER_BIT);
    glm::vec3 cameraPos = ExtractCameraPos(matView);
    glUseProgram( DepthMap_idProgram );
    myCamera.SendPV(DepthMap_idProgram,"matProj","matView");

    glUniformMatrix4fv( glGetUniformLocation( DepthMap_idProgram, "lightProj" ), 1, GL_FALSE, glm::value_ptr(lightProj) );
    glUniformMatrix4fv( glGetUniformLocation( DepthMap_idProgram, "lightView" ), 1, GL_FALSE, glm::value_ptr(lightView) );


    matModel = glm::mat4(1.0);
    matModel = glm::rotate(matModel, 0.0f, glm::vec3(1.0, 0.0, 0.0));
    matModel = glm::rotate(matModel, 0.0f, glm::vec3(0.0, 1.0, 0.0));
    matModel = glm::translate(matModel, glm::vec3(0.0, 0.0, 0.0));
    matModelGrave = glm::translate(matModel, glm::vec3(0.0, 0.2, 0.0));

    matModelGhost = glm::translate(matModel, glm::vec3(0.0, height, 0.0));
    matModelCube = glm::mat4(1.0);
    matModelCube = glm::translate(matModel, glm::vec3(-4.0, 1.0, -3.0));
    matModelCube = glm::rotate(matModelCube, angleXCube, glm::vec3(1.0, 0.0, 0.0));
    matModelCube = glm::rotate(matModelCube, angleYCube, glm::vec3(0.0, 1.0, 0.0));

    matModelRaven = glm::mat4(1.0);
    matModelRaven = glm::translate(matModel, glm::vec3(-6.0, 1.0, -4.0));
    matModelRaven = glm::rotate(matModelRaven, angleXCube, glm::vec3(1.0, 0.0, 0.0));
    matModelRaven = glm::rotate(matModelRaven, angleYCube, glm::vec3(0.0, 1.0, 0.0));
    ground3D.Draw(matModel);
    for(int i=0; i<6; i++)
    {
        if(i%2==0)
        {
            matModelGrave = glm::translate(matModel, glm::vec3(i+i*i, myGround.getAltitute( glm::vec2(i+i*i, i+i*i )), i+i*i));
            grave3D.Draw(matModelGrave);

        }
        else
        {
            matModelGrave = glm::translate(matModel, glm::vec3(i-i*i,myGround.getAltitute( glm::vec2(i-i*i, i-i*i )), i-i*i));
            grave3D.Draw(matModelGrave);

        }
    }
    ghost3D.Draw(matModelGhost);
    for(int i=0; i<10; i++)
    {
        if(!myPlayer.eaten[i])
        {
            matModelCube=matModelCubeTab[i];
            cube3D.Draw(matModelCube);
        }
    }
    raven3D.DrawMultiple(matModelRaven);

    // WYLACZAMY program
    glUseProgram(0);
}
void Render_Scene()
{
    matView=myCamera.matView;

    glm::vec3 cameraPos = ExtractCameraPos(matView);

    matModel = glm::mat4(1.0);
    matModel = glm::rotate(matModel, 0.0f, glm::vec3(1.0, 0.0, 0.0));
    matModel = glm::rotate(matModel, 0.0f, glm::vec3(0.0, 1.0, 0.0));
    matModel = glm::translate(matModel, glm::vec3(0.0, 0.0, 0.0));
    myLight.Position.x = lightPositionX;

    skybox.Draw(matProj,matView,changeSkybox);
    SentLightParameters();
    mainProgram.Use();
    myCamera.Update(myPlayer);
    myCamera.SendPV(mainProgram.idProgram,"matProj","matView");
    shadowPointLight.SendUniforms(mainProgram.idProgram, 9, cameraPos,randomLights);
    mainProgram.SetMVP(matView,matProj,true,false);

    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, ground3D.material.texture.id);
    mainProgram.SendInt("textureSampler",0);
    glActiveTexture(GL_TEXTURE2);
    glBindTexture(GL_TEXTURE_2D, DepthMap_idTexture);
    mainProgram.SendInt( "tex_shadowMap", 2);
    mainProgram.SendInt("useBlinnPhong",useBlinnPhong);
    mainProgram.SendInt("useLight", useLight);
    mainProgram.SendInt( "tex_skybox", 7);
    mainProgram.SendInt("useShadowMapping",useShadowMapping);
    mainProgram.SendInt("useShadowCubeMapping",useShadowCubeMapping);

    mainProgram.SendInt( "isGhost",false);
    //inshadow_dir
    SendLightParameters(mainProgram.idProgram);
    mainProgram.SendMaterial(myMaterial);

    ground3D.Draw(matModel);
    glUseProgram( 0 );

    RenderGraves(matView);

    matModelGhost = glm::translate(matModel, glm::vec3(0.0, height, 0.0));

    ghostProgram.Use();
    shadowPointLight.SendUniforms(ghostProgram.idProgram, 9, cameraPos,randomLights);
    ghostProgram.SendFloat("height", height);
    ghostProgram.SetMVP(matView,matProj,true,false);
    glActiveTexture(GL_TEXTURE3);
    glBindTexture(GL_TEXTURE_2D, ghost3D.material.texture.id);
    ghostProgram.SendInt( "textureSampler", 3);
    glActiveTexture(GL_TEXTURE2);
    glBindTexture(GL_TEXTURE_2D, DepthMap_idTexture);
    ghostProgram.SendInt( "tex_shadowMap", 2);
    ghostProgram.SendInt( "useLight", useLight);
    ghostProgram.SendInt( "tex_skybox", 7);
    ghostProgram.SendInt("useShadowMapping",useShadowMapping);
    ghostProgram.SendInt("useShadowCubeMapping",useShadowCubeMapping);

    ghostProgram.SendInt( "isGhost", false);
    SendLightParameters(ghostProgram.idProgram);

    ghostProgram.SendInt( "isReflectOn", isReflectOn);
    ghostProgram.SendMaterial(myMaterial);
    ghost3D.Draw(matModelGhost);
    glUseProgram( 0 );

    RenderCube(matView);


    matModelRaven = glm::mat4(1.0);
    matModelRaven = glm::translate(matModel, glm::vec3(-6.0, 1.0, -4.0));
    matModelRaven = glm::rotate(matModelRaven, angleXCube, glm::vec3(1.0, 0.0, 0.0));
    matModelRaven = glm::rotate(matModelRaven, angleYCube, glm::vec3(0.0, 1.0, 0.0));
    ravenProgram.Use();
    shadowPointLight.SendUniforms(ravenProgram.idProgram, 9, cameraPos,randomLights);

    ravenProgram.SetMVPMultiple(matView,matProj,true,false);
    glActiveTexture(GL_TEXTURE5);
    glBindTexture(GL_TEXTURE_2D, raven3D.material.texture.id);
    glActiveTexture(GL_TEXTURE2);
    glBindTexture(GL_TEXTURE_2D, DepthMap_idTexture);
    ravenProgram.SendInt( "tex_shadowMap", 2);
    ravenProgram.SendInt( "textureSampler", 5);
    ravenProgram.SendFloat("Time", Time);
    ravenProgram.SendInt( "useLight", useLight);
    ravenProgram.SendInt( "tex_skybox", 7);
    ravenProgram.SendInt("useShadowMapping",useShadowMapping);
    ravenProgram.SendInt("useShadowCubeMapping",useShadowCubeMapping);

    ravenProgram.SendInt("isReflectOn", isReflectOn);
    ravenProgram.SendInt("isGhost", false);

    SendLightParameters(ravenProgram.idProgram);

    raven3D.DrawMultiple(matModelRaven);
    glUseProgram( 0 );

    glm::mat4 matProj1, matView1, matModel1;
    matProj1 = glm::perspective(glm::radians(45.0f), (float)glutGet(GLUT_WINDOW_WIDTH)/(float)glutGet(GLUT_WINDOW_HEIGHT), 5.0f, 100.0f);
    matView1 = glm::lookAt(glm::vec3(0.0f, 0.0f, 5.0f), glm::vec3(0.0f, 0.0f, 0.0f), glm::vec3(0.0f, 1.0f, 0.0f));
    matModel1 = glm::mat4(1.0f);
    matModel1 = glm::translate(matModel1, glm::vec3(0.9f, 0.9f, 0.0f));   // Corrected the translation values
    matModel1 = glm::scale(matModel1, glm::vec3(0.01f, 0.01f, 0.01f));
    if(showMinimap && !postprocessing)
    {
        squareProgram.Use();

        glUniformMatrix4fv(glGetUniformLocation(squareProgram.idProgram, "matProj"), 1, GL_FALSE, glm::value_ptr(matProj1));
        glUniformMatrix4fv(glGetUniformLocation(squareProgram.idProgram, "matView"), 1, GL_FALSE, glm::value_ptr(matView1));
        glUniformMatrix4fv(glGetUniformLocation(squareProgram.idProgram, "matModel"), 1, GL_FALSE, glm::value_ptr(matModel1));
        glBindVertexArray(vArray);
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, idTextureBuffer);
        glDrawArrays(GL_TRIANGLES, 0, 6);
        glUseProgram(0);
    }
    if(postprocessing)
    {
        postProgram.Use();
        glUniformMatrix4fv(glGetUniformLocation(postProgram.idProgram, "matProj"), 1, GL_FALSE, glm::value_ptr(matProj1));
        glUniformMatrix4fv(glGetUniformLocation(postProgram.idProgram, "matView"), 1, GL_FALSE, glm::value_ptr(matView1));
        glUniformMatrix4fv(glGetUniformLocation(postProgram.idProgram, "matModel"), 1, GL_FALSE, glm::value_ptr(matModel1));
        postProgram.SendInt("splotEffect",splotEffect);
        postProgram.SendInt("funEffect",funEffect);
        glBindVertexArray(vArrayPost);
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, idPostTextureBuffer);
        glDrawArrays(GL_TRIANGLES, 0, 6);
        glUseProgram(0);
    }
    if(showPointLightSpheres)
    {
        matModelSphere = glm::translate(matModel, redLight.Position);
        sphereProgram.Use();
        sphereProgram.SendMaterial(myMaterial);
        sphereProgram.SendInt( "useLight", false);
        sphereProgram.SendInt( "tex_skybox", 7);
        sphereProgram.SendInt( "isGhost", false);
        sphereProgram.SendInt("useShadowMapping",useShadowMapping);
        sphereProgram.SendInt("useShadowCubeMapping",useShadowCubeMapping);

        sphereProgram.SendInt( "color", 1);
        sphereProgram.SetMVP(matView,matProj,false,false);
        sphere3D.Draw(matModelSphere);
        glUseProgram( 0 );

        matModelSphere = glm::translate(matModel, greenLight.Position);
        sphereProgram.Use();
        sphereProgram.SendMaterial(myMaterial);
        sphereProgram.SendInt( "useLight", false);
        sphereProgram.SendInt( "tex_skybox", 7);
        sphereProgram.SendInt( "isGhost", false);
        sphereProgram.SendInt("useShadowMapping",useShadowMapping);
        sphereProgram.SendInt("useShadowCubeMapping",useShadowCubeMapping);

        sphereProgram.SendInt( "color", 2);
        sphereProgram.SetMVP(matView,matProj,false,false);
        sphere3D.Draw(matModelSphere);
        glUseProgram( 0 );

        matModelSphere = glm::translate(matModel, blueLight.Position );
        sphereProgram.Use();
        sphereProgram.SendMaterial(myMaterial);
        sphereProgram.SendInt( "useLight", false);
        sphereProgram.SendInt( "tex_skybox", 7);
        sphereProgram.SendInt("useShadowMapping",useShadowMapping);
        sphereProgram.SendInt( "isGhost", false);
        sphereProgram.SendInt( "color", 3);
        sphereProgram.SetMVP(matView,matProj,false,false);
        sphere3D.Draw(matModelSphere);
        glUseProgram( 0 );

        matModelSphere = glm::translate(matModel, myLight.Position);
        sphereProgram.Use();
        sphereProgram.SendMaterial(myMaterial);
        sphereProgram.SendInt( "useLight", false);
        sphereProgram.SendInt( "tex_skybox", 7);
        sphereProgram.SendInt( "isGhost", false);
        sphereProgram.SendInt("useShadowMapping",useShadowMapping);
        sphereProgram.SendInt("useShadowCubeMapping",useShadowCubeMapping);

        sphereProgram.SendInt( "color", 4);
        sphereProgram.SetMVP(matView,matProj,false,false);
        sphere3D.Draw(matModelSphere);
        glUseProgram( 0 );
    }
}
void Render_Minimap()
{
    matView=myCamera.matView;


    if(showMinimap)
    {
        matViewMap = glm::mat4(1.0);
        matViewMap = glm::rotate(matViewMap, glm::radians(90.0f), glm::vec3(1.0, 0.0, 0.0));
        matViewMap = glm::rotate(matViewMap,0.0f, glm::vec3(0.0, 1.0, 0.0));
        matViewMap = glm::translate(matViewMap, glm::vec3(myPlayer.Position.x, -20.0, myPlayer.Position.z));
        glm::vec3 cameraPos = ExtractCameraPos(matViewMap);
    }
    else
    {
        glm::vec3 cameraPos = ExtractCameraPos(matView);
        matViewMap=matView;
    }
    matModel = glm::mat4(1.0);
    matModel = glm::rotate(matModel, 0.0f, glm::vec3(1.0, 0.0, 0.0));
    matModel = glm::rotate(matModel, 0.0f, glm::vec3(0.0, 1.0, 0.0));
    matModel = glm::translate(matModel, glm::vec3(0.0, 0.0, 0.0));
    myLight.Position.x = lightPositionX;

    SentLightParameters();
    mainProgram.Use();
    shadowPointLight.SendUniforms(mainProgram.idProgram, 9, cameraPos,randomLights);

    mainProgram.SetMVP(matViewMap,matProj,true,false);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, ground3D.material.texture.id);
    mainProgram.SendInt("textureSampler",0);
    glActiveTexture(GL_TEXTURE2);
    glBindTexture(GL_TEXTURE_2D, DepthMap_idTexture);
    mainProgram.SendInt( "tex_shadowMap", 2);
    mainProgram.SendInt("useBlinnPhong",useBlinnPhong);
    mainProgram.SendInt("useLight", useLight);
    mainProgram.SendInt( "tex_skybox", 7);
    mainProgram.SendInt("useShadowMapping",useShadowMapping);
    mainProgram.SendInt("useShadowCubeMapping",useShadowCubeMapping);

    mainProgram.SendInt( "isGhost",false);
    //inshadow_dir
    SendLightParameters(mainProgram.idProgram);
    mainProgram.SendMaterial(myMaterial);

    ground3D.Draw(matModel);
    glUseProgram( 0 );
    skybox.Draw(matProj,matViewMap,changeSkybox);
    RenderGraves(matViewMap);

    matModelGhost = glm::translate(matModel, glm::vec3(0.0, height, 0.0));

    ghostProgram.Use();
    shadowPointLight.SendUniforms(ghostProgram.idProgram, 9, cameraPos,randomLights);

    ghostProgram.SendFloat("height", height);
    ghostProgram.SetMVP(matViewMap,matProj,true,false);
    glActiveTexture(GL_TEXTURE3);
    glBindTexture(GL_TEXTURE_2D, ghost3D.material.texture.id);
    ghostProgram.SendInt( "textureSampler", 3);
    glActiveTexture(GL_TEXTURE2);
    glBindTexture(GL_TEXTURE_2D, DepthMap_idTexture);
    ghostProgram.SendInt( "tex_shadowMap", 2);
    ghostProgram.SendInt( "useLight", useLight);
    ghostProgram.SendInt( "tex_skybox", 7);
    ghostProgram.SendInt("useShadowMapping",useShadowMapping);
    ghostProgram.SendInt("useShadowCubeMapping",useShadowCubeMapping);

    ghostProgram.SendInt( "isGhost", false);
    SendLightParameters(ghostProgram.idProgram);

    ghostProgram.SendInt( "isReflectOn", isReflectOn);
    ghostProgram.SendMaterial(myMaterial);
    ghost3D.Draw(matModelGhost);
    glUseProgram( 0 );

    matModelCube = glm::mat4(1.0);
    matModelCube = glm::translate(matModel, glm::vec3(-4.0, 1.0, -3.0));
    matModelCube = glm::rotate(matModelCube, angleXCube, glm::vec3(1.0, 0.0, 0.0));
    matModelCube = glm::rotate(matModelCube, angleYCube, glm::vec3(0.0, 1.0, 0.0));
    RenderCube(matViewMap);


    matModelRaven = glm::mat4(1.0);
    matModelRaven = glm::translate(matModel, glm::vec3(-6.0, 1.0, -4.0));
    matModelRaven = glm::rotate(matModelRaven, angleXCube, glm::vec3(1.0, 0.0, 0.0));
    matModelRaven = glm::rotate(matModelRaven, angleYCube, glm::vec3(0.0, 1.0, 0.0));
    ravenProgram.Use();
    shadowPointLight.SendUniforms(ravenProgram.idProgram, 9, cameraPos,randomLights);

    ravenProgram.SetMVPMultiple(matView,matProj,true,false);
    glActiveTexture(GL_TEXTURE5);
    glBindTexture(GL_TEXTURE_2D, raven3D.material.texture.id);
    glActiveTexture(GL_TEXTURE2);
    glBindTexture(GL_TEXTURE_2D, DepthMap_idTexture);
    ravenProgram.SendInt( "tex_shadowMap", 2);
    ravenProgram.SendInt( "textureSampler", 5);
    ravenProgram.SendFloat("Time", Time);
    ravenProgram.SendInt( "useLight", useLight);
    ravenProgram.SendInt( "tex_skybox", 7);
    ravenProgram.SendInt("useShadowMapping",useShadowMapping);
    ravenProgram.SendInt("useShadowCubeMapping",useShadowCubeMapping);

    ravenProgram.SendInt("isReflectOn", isReflectOn);
    ravenProgram.SendInt("isGhost", false);

    glUseProgram(0);


    if(showPointLightSpheres)
    {
        matModelSphere = glm::translate(matModel, redLight.Position);
        sphereProgram.Use();
        shadowPointLight.SendUniforms(sphereProgram.idProgram, 9, cameraPos,randomLights);

        sphereProgram.SendMaterial(myMaterial);
        sphereProgram.SendInt( "useLight", false);
        sphereProgram.SendInt( "tex_skybox", 7);
        sphereProgram.SendInt( "isGhost", false);
        sphereProgram.SendInt("useShadowMapping",useShadowMapping);
        sphereProgram.SendInt( "color", 1);
        sphereProgram.SendInt("useShadowCubeMapping",useShadowCubeMapping);

        sphereProgram.SetMVP(matViewMap,matProj,false,false);
        sphere3D.Draw(matModelSphere);
        glUseProgram( 0 );

        matModelSphere = glm::translate(matModel, greenLight.Position);
        sphereProgram.Use();
        shadowPointLight.SendUniforms(sphereProgram.idProgram, 9, cameraPos,randomLights);

        sphereProgram.SendMaterial(myMaterial);
        sphereProgram.SendInt( "useLight", false);
        sphereProgram.SendInt( "tex_skybox", 7);
        sphereProgram.SendInt( "isGhost", false);
        sphereProgram.SendInt("useShadowMapping",useShadowMapping);
        sphereProgram.SendInt("useShadowCubeMapping",useShadowCubeMapping);

        sphereProgram.SendInt( "color", 2);
        sphereProgram.SetMVP(matViewMap,matProj,false,false);
        sphere3D.Draw(matModelSphere);
        glUseProgram( 0 );

        matModelSphere = glm::translate(matModel, blueLight.Position );
        sphereProgram.Use();
        shadowPointLight.SendUniforms(sphereProgram.idProgram, 9, cameraPos,randomLights);

        sphereProgram.SendMaterial(myMaterial);
        sphereProgram.SendInt( "useLight", false);
        sphereProgram.SendInt( "tex_skybox", 7);
        sphereProgram.SendInt("useShadowMapping",useShadowMapping);
        sphereProgram.SendInt("useShadowCubeMapping",useShadowCubeMapping);

        sphereProgram.SendInt( "isGhost", false);
        sphereProgram.SendInt( "color", 3);
        sphereProgram.SetMVP(matViewMap,matProj,false,false);
        sphere3D.Draw(matModelSphere);
        glUseProgram( 0 );

        matModelSphere = glm::translate(matModel, myLight.Position);
        sphereProgram.Use();
        shadowPointLight.SendUniforms(sphereProgram.idProgram, 9, cameraPos,randomLights);

        sphereProgram.SendMaterial(myMaterial);
        sphereProgram.SendInt( "useLight", false);
        sphereProgram.SendInt( "tex_skybox", 7);
        sphereProgram.SendInt( "isGhost", false);
        sphereProgram.SendInt("useShadowMapping",useShadowMapping);
        sphereProgram.SendInt("useShadowCubeMapping",useShadowCubeMapping);

        sphereProgram.SendInt( "color", 4);
        sphereProgram.SetMVP(matViewMap,matProj,false,false);
        sphere3D.Draw(matModelSphere);
        glUseProgram( 0 );
    }
}
void RenderText(){

    int trueCount = 0;

    for (int i = 0; i < 10; ++i) {
        if (myPlayer.eaten[i]) {
            trueCount++;
        }
    }
 char txt[255];
    sprintf(txt, "Bones: %i", trueCount);

    RenderText(txt, 25, 25, 1.0f, glm::vec3(0.5, 0.8f, 0.2f));
    RenderText("ESC - Exit", 25, 450, 0.5f, glm::vec3(0.3, 0.7f, 0.9f));
    if(trueCount==10){
        RenderText("You won", 25, 70, 0.5f, glm::vec3(0.1, 0.1, 1.0f));
    }
}
// ---------------------------------------
void DisplayScene()
{
    matView=myCamera.matView;

    if(useShadowCubeMapping)
    {
        RenderScene_to_ShadowCubeMap();
    }
    if(useShadowMapping)
    {
        RenderScene_to_ShadowMap();
    }
    if(showMinimap && !postprocessing)
    {
        glBindFramebuffer(GL_FRAMEBUFFER, idFrameBuffer);
        glViewport(0, 0, Buffer_Width, Buffer_Height);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        Render_Minimap();
    }
    if(postprocessing)
    {
        glBindFramebuffer(GL_FRAMEBUFFER, idPostFrameBuffer);
        glViewport(0, 0, Buffer_Width, Buffer_Height);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        Render_Minimap();
    }
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
    glViewport(0, 0, glutGet(GLUT_WINDOW_WIDTH), glutGet(GLUT_WINDOW_HEIGHT));
    glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
    Render_Scene();
    RenderText();
    glutSwapBuffers();
}

void Initialize()
{
    InitText("text/arial.ttf", 36);

    stbi_set_flip_vertically_on_load(true);
    glPixelStorei(GL_UNPACK_ALIGNMENT,1);
    glClearColor( 0.5f, 0.5f, 0.5f, 1.0f );

    skybox.Create(changeSkybox);
    myLight.Position = vec3(lightPositionX, 3.0, 1.0);

    mainProgram.CreateProgram();
    mainProgram.LoadShaders("shaders/vertex.glsl", "shaders/fragment.glsl");
    mainProgram.LinkAndValidate();
    graveProgram.CreateProgram();
    graveProgram.LoadShaders("shaders/vertex.glsl", "shaders/fragment.glsl");
    graveProgram.LinkAndValidate();

    ghostProgram.CreateProgram();
    ghostProgram.LoadShaders("shaders/vertex.glsl", "shaders/fragment.glsl");
    ghostProgram.LinkAndValidate();

    cubeProgram.CreateProgram();
    cubeProgram.LoadShaders("shaders/vertex.glsl", "shaders/fragment.glsl");
    cubeProgram.LinkAndValidate();

    sphereProgram.CreateProgram();
    sphereProgram.LoadShaders("shaders/vertex.glsl", "shaders/fragment.glsl");
    sphereProgram.LinkAndValidate();

    ravenProgram.CreateProgram();
    ravenProgram.LoadShaders("shaders/raven-vertex.glsl", "shaders/fragment.glsl");
    ravenProgram.LinkAndValidate();

    squareProgram.CreateProgram();
    squareProgram.LoadShaders("shaders/square-vertex.glsl", "shaders/square-fragment.glsl");
    squareProgram.LinkAndValidate();
    MakeSquare();
    postProgram.CreateProgram();
    postProgram.LoadShaders("shaders/square-vertex.glsl", "shaders/square-fragment.glsl");
    postProgram.LinkAndValidate();
    MakeRectangle();

    grave3D.CreateFromOBJ("obj/grave.obj");
    ground3D.CreateFromOBJ("obj/ground-2.obj");
    ghost3D.CreateFromOBJ("obj/ghost.obj");
    cube3D.CreateFromOBJ("obj/koscior.obj");
    sphere3D.CreateFromOBJ("obj/sphere.obj");
    raven3D.CreateFromObjMultiple("obj/raven.obj");

    grave3D.material.texture = LoadTexture("textures/grave_texture.jpg");
    ground3D.material.texture = LoadTexture("textures/negy.jpg");
    ghost3D.material.texture = LoadTexture("textures/white_texture.jpg");
    cube3D.material.texture = LoadTexture("textures/white_texture.jpg");
    raven3D.material.texture = LoadTexture("textures/raven_texture.jpg");

    myGround.Init(ground3D.vertices);
    myPlayer.SetPosition(glm::vec3(3.0, 0.0, 4.0));
    myCamera.Init(myPlayer);
    myCamera.Update(myPlayer);
    matModelCubeInit();
     for(int i =0 ; i<10; i++)
    {
        myPlayer.matModelCubeTab2[i]= glm::vec3(matModelCubeTab[i][3]);
        printf("%f %f %f",myPlayer.matModelCubeTab2[i].x,myPlayer.matModelCubeTab2[i].y,myPlayer.matModelCubeTab2[i].z);
    }
    InitFrame();
    ShadowMapDir_Init();
    glEnable( GL_DEPTH_TEST );
    shadowPointLight.Init(glm::vec3(0.0, 5.0, 0.0));
    randomLights[0]=glm::vec3(0.0, 5.0, 0.0);
    randomLights[1]=glm::vec3(-1.0, 1.0, -1.0);
    randomLights[2]=glm::vec3(-20.0, 4.0, -20.0);
    randomLights[3]=glm::vec3(40.0, 2.0, -10.0);
}

void Reshape( int width, int height )
{
    glViewport( 0, 0, width, height );
    matProj = glm::perspectiveFov(glm::radians(60.0f), (float)width, (float)height, 0.1f, 100.f );
    myCamera.matProj=glm::perspectiveFov(glm::radians(60.0f), (float)width, (float)height, 0.1f, 100.f );
}

// --------------------------------------------------------------
void Keyboard( unsigned char key, int x, int y )
{

    switch(key)
    {
    case 27:	// ESC key
        exit(0);
        break;

    case 'w':

        myPlayer.Move(0.1,myGround);
        break;

    case 's':
        myPlayer.Move(-0.1,myGround);

        break;

    case 'd':
        myPlayer.Rotate(-0.1,myGround);
        break;

    case 'a':
        myPlayer.Rotate(0.1,myGround);

        break;

    }

    glutPostRedisplay();
}
int main( int argc, char *argv[] )
{
    glutInit( &argc, argv );
    glutInitDisplayMode( GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH );
    //Menu not working in other case
    //glutInitContextVersion( 3, 2 );
    //glutInitContextProfile( GLUT_CORE_PROFILE );
    glutInitWindowSize( 500, 500 );
    glutCreateWindow( "Project" );
    glutDisplayFunc( DisplayScene );
    glutReshapeFunc( Reshape );
    glutMouseFunc( MouseButton );
    glutMotionFunc( MouseMotion );
    glutMouseWheelFunc( MouseWheel );
    glutKeyboardFunc( Keyboard );
    glutSpecialFunc( SpecialKeys );
    // GLEW
    glewExperimental = GL_TRUE;
    GLenum err = glewInit();
    if( GLEW_OK != err )
    {
        printf("GLEW Error\n");
        exit(1);
    }

    // OpenGL
    if( !GLEW_VERSION_3_2 )
    {
        printf("No OpenGL 3.2!\n");
        exit(1);
    }
    int underMenuA = glutCreateMenu( Menu );
    glutAddMenuEntry( "Phong- Animation", 3 );
    glutAddMenuEntry( "Phong", 6 );
    glutAddMenuEntry( "Direction", 5 );

    int underMenuB = glutCreateMenu( Menu );
    glutAddMenuEntry( "Bling-Phong", 1 );
    glutAddMenuEntry( "Phong", 2 );
    int underMenuC = glutCreateMenu( Menu );
    glutAddMenuEntry( "Splot", 10 );
    glutAddMenuEntry( "Fun", 11 );


    glutCreateMenu( Menu );
    glutAddSubMenu( "Point & Direction", underMenuA );
    glutAddSubMenu( "Reflective", underMenuB );
    glutAddMenuEntry( "Turn off", 4 );
    glutAddMenuEntry( "Change skybox", 7 );
    glutAddMenuEntry( "On/Off EM", 8 );
    glutAddMenuEntry( "On/Off Minimap", 9 );
    glutAddSubMenu( "On/Off Postprocessing", underMenuC );
    glutAddMenuEntry( "Shadow Mapping", 12 );
    glutAddMenuEntry( "Cube Shadow Mapping with RPOL", 13 );
    //random place of light :D
    glutAttachMenu( GLUT_RIGHT_BUTTON );

    glutIdleFunc ( Animation );
    Initialize();

    glutMainLoop();


    // Cleaning
    mainProgram.Clean();
    ground3D.Clean();

    graveProgram.Clean();
    grave3D.Clean();

    cubeProgram.Clean();
    cube3D.Clean();

    ghostProgram.Clean();
    ghost3D.Clean();

    sphereProgram.Clean();
    sphere3D.Clean();

    ravenProgram.Clean();
    raven3D.Clean();

    return 0;
}
