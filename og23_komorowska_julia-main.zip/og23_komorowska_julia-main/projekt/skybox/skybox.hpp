#ifndef __SKYBOX_H
#define __SKYBOX_H

#include <GL/glew.h>
#include <glm/glm.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <string>
#include <vector>
#include "stb_image.h"

class CSkyBox
{
public:
    CSkyBox();
    ~CSkyBox();
    GLuint SkyBox_Texture[2];
    GLuint SkyBox_VAO;
    GLuint SkyBox_Program;

    void Draw(glm::mat4 matProj, glm::mat4 matView,bool changeSkybox);
    void Create(bool changeSkybox);
    GLuint GetMyCurrentTexture(bool changeSkybox);
};
CSkyBox::CSkyBox()
{

}

CSkyBox::~CSkyBox()
{
    glDeleteVertexArrays(1, &SkyBox_VAO);
    glDeleteProgram(SkyBox_Program);
    glDeleteTextures(2, SkyBox_Texture);
}

void CSkyBox::Create(bool changeSkybox)
{
    GLfloat positions[8*3] =
    {
        1.0f, 1.0f, 1.0f,   // 0
        -1.0f, 1.0f, 1.0f,  // 1
        -1.0f, -1.0f, 1.0f, // 2
        1.0f, -1.0f, 1.0f,  // 3
        1.0f, 1.0f, -1.0f,  // 4
        -1.0f, 1.0f, -1.0f, // 5
        -1.0f, -1.0f, -1.0f,// 6
        1.0f, -1.0f, -1.0f  // 7
    };

    GLuint indices[12*3] =
    {
        5, 0, 1,
        5, 4, 0,
        2, 0, 3,
        2, 1, 0,
        7, 0, 4,
        7, 3, 0,
        3, 6, 2,
        3, 7, 6,
        1, 2, 6,
        1, 6, 5,
        4, 5, 6,
        4, 6, 7
    };


    const char files[6][30] =
    {
        "skybox/skybox1/posx.jpg",
        "skybox/skybox1/negx.jpg",
        "skybox/skybox1/posy.jpg",
        "skybox/skybox1/negy.jpg",
        "skybox/skybox1/posz.jpg",
        "skybox/skybox1/negz.jpg",
    };

    const char files2[6][30] =
    {
        "skybox/skybox2/posx.jpg",
        "skybox/skybox2/negx.jpg",
        "skybox/skybox2/posy.jpg",
        "skybox/skybox2/negy.jpg",
        "skybox/skybox2/posz.jpg",
        "skybox/skybox2/negz.jpg",
    };

    const GLenum targets[6] =
    {
        GL_TEXTURE_CUBE_MAP_POSITIVE_X,
        GL_TEXTURE_CUBE_MAP_NEGATIVE_X,
        GL_TEXTURE_CUBE_MAP_POSITIVE_Y,
        GL_TEXTURE_CUBE_MAP_NEGATIVE_Y,
        GL_TEXTURE_CUBE_MAP_POSITIVE_Z,
        GL_TEXTURE_CUBE_MAP_NEGATIVE_Z
    };

    // Program
    SkyBox_Program = glCreateProgram();
    glAttachShader( SkyBox_Program, LoadShader(GL_VERTEX_SHADER, "skybox/skybox-vertex.glsl"));
    glAttachShader( SkyBox_Program, LoadShader(GL_FRAGMENT_SHADER, "skybox/skybox-fragment.glsl"));
    LinkAndValidateProgram( SkyBox_Program );
    // Vertex arrays
    glGenVertexArrays( 1, &SkyBox_VAO );
    glBindVertexArray( SkyBox_VAO );
    // Wspolrzedne wierzchokow
    GLuint vBuffer_pos;
    glGenBuffers( 1, &vBuffer_pos );
    glBindBuffer( GL_ARRAY_BUFFER, vBuffer_pos );
    glBufferData( GL_ARRAY_BUFFER, 8*3*sizeof(GLfloat), positions, GL_STATIC_DRAW );
    glVertexAttribPointer( 0, 3, GL_FLOAT, GL_FALSE, 0, NULL );
    glEnableVertexAttribArray( 0 );
    // Tablica indeksow
    GLuint vBuffer_idx;
    glGenBuffers( 1, &vBuffer_idx );
    glBindBuffer( GL_ELEMENT_ARRAY_BUFFER, vBuffer_idx );
    glBufferData( GL_ELEMENT_ARRAY_BUFFER, 12*3*sizeof( GLuint ), indices, GL_STATIC_DRAW );
    glBindVertexArray( 0 );


    // Tekstura CUBE_MAP
    glGenTextures( 2, SkyBox_Texture);
    glBindTexture( GL_TEXTURE_CUBE_MAP, SkyBox_Texture[0] );
    stbi_set_flip_vertically_on_load(false);

    // Wylaczanie flipowania tekstury
    for (int i = 0; i < 6; ++i)
    {
        int tex_width, tex_height, n;
        unsigned char *tex_data;

        tex_data = stbi_load(files[i], &tex_width, &tex_height, &n, 0);

        if (tex_data == NULL)
        {
            printf("Image %s can't be loaded!\n", files[i]);
            exit(1);
        }

        glTexImage2D(targets[i], 0, GL_RGB, tex_width, tex_height, 0, GL_RGB, GL_UNSIGNED_BYTE, tex_data);

        // Zwolnienie pamięci pliku graficznego
        stbi_image_free(tex_data);
    }
    glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_MIN_FILTER, GL_NEAREST_MIPMAP_LINEAR);
    glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_R, GL_REPEAT);
    glGenerateMipmap(GL_TEXTURE_CUBE_MAP);


    // Powrót flipowania tekstury
    stbi_set_flip_vertically_on_load(true);
    glBindTexture( GL_TEXTURE_CUBE_MAP, SkyBox_Texture[1] );
    stbi_set_flip_vertically_on_load(false);

    for (int i = 0; i < 6; ++i)
    {
        int tex_width2, tex_height2, n2;
        unsigned char *tex_data2;

        tex_data2 = stbi_load(files2[i], &tex_width2, &tex_height2, &n2, 0);

        if (tex_data2 == NULL)
        {
            printf("Image %s can't be loaded!\n", files2[i]);
            exit(1);
        }

        glTexImage2D(targets[i], 0, GL_RGB, tex_width2, tex_height2, 0, GL_RGB, GL_UNSIGNED_BYTE, tex_data2);

        // Zwolnienie pamięci pliku graficznego
        stbi_image_free(tex_data2);
    }

    // Przykładowe opcje tekstury
    glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_MIN_FILTER, GL_NEAREST_MIPMAP_LINEAR);
    glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_R, GL_REPEAT);
    glGenerateMipmap(GL_TEXTURE_CUBE_MAP);


    // Powrót flipowania tekstury
    stbi_set_flip_vertically_on_load(true);
}

void CSkyBox::Draw(glm::mat4 matProj, glm::mat4 matView,bool changeSkybox)
{
// Specjalny potok dla SkyBoxa (uproszczony)
    // Ten program nie ma oswietlenia/cieni itp.
    glUseProgram(SkyBox_Program);

    // Przeskalowanie boxa i przeslanie macierzy rzutowania
    // korzystajac z macierzy Proj i View naszej sceny
    glm::mat4 matPVM = matProj * matView * glm::scale(glm::mat4(1), glm::vec3(40.0, 40.0, 40.0));
    glUniformMatrix4fv( glGetUniformLocation( SkyBox_Program, "matPVM" ), 1, GL_FALSE, glm::value_ptr(matPVM) );
    glActiveTexture(GL_TEXTURE7);
    // Aktywacja tekstury CUBE_MAP
    if(changeSkybox)
    {
        glBindTexture( GL_TEXTURE_CUBE_MAP, SkyBox_Texture[0] );
    }
    else
    {
        glBindTexture( GL_TEXTURE_CUBE_MAP, SkyBox_Texture[1] );
    }
    glUniform1i(glGetUniformLocation(SkyBox_Program, "tex_skybox"), 7);

    // Rendering boxa
    glBindVertexArray( SkyBox_VAO );
    glDrawElements( GL_TRIANGLES, 36, GL_UNSIGNED_INT, NULL );
    glBindVertexArray( SkyBox_VAO );

    glUseProgram(0);
}
GLuint CSkyBox::GetMyCurrentTexture(bool changeSkybox){
    if(changeSkybox){
        return SkyBox_Texture[0];
    }
    return SkyBox_Texture[1];
}

#endif // __SKYBOX_H
