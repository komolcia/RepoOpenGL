#include <stdio.h>
#include <GL/glew.h>
#include <GL/freeglut.h>
#include <cmath>

#include "shader_stuff.h"


// ---------------------------------------
// Identyfikatory obiektow OpenGL

GLuint idProgram;	// programu
GLuint idProgram2;	// programu 2
GLuint idVAO;		// tablic wierzcholkow
GLuint idVBO_coord; // bufora na wspolrzedne

// ---------------------------------------
// Wspolrzedne wierzchokow

#define N 8

GLfloat vertices[N * 2];
GLfloat outlineVertices[N * 2];

bool spacja = true;

void calculateVertices() {
   for (int i = 0; i < N; ++i) {
        double angle = 2.0 * M_PI * i / N;
        vertices[i * 2] = cos(angle);
        vertices[i * 2 + 1] = sin(angle);
        outlineVertices[i * 2] = 250.0 + 220.0 * cos(angle);
        outlineVertices[i * 2 + 1] = 250.0 + 220.0 * sin(angle);
    }
}
// ---------------------------------------
void DisplayScene()
{
	// ---------------------------
	// Etap (5) rendering
	// ---------------------------
	glClear( GL_COLOR_BUFFER_BIT );
	if( spacja == true){
        glUseProgram( idProgram );
	} else{
	    glUseProgram( idProgram2 );
	    glBindVertexArray( idVAO );
	    glDrawArrays(GL_LINE_LOOP, 0, N);
	    glBindVertexArray( 0 );

	}

		// Generowanie obiektow na ekranie
		glBindVertexArray( idVAO );
		glDrawArrays( GL_TRIANGLE_FAN, 0, N );
    if (spacja == false) {

        GLint useOutlineLoc = glGetUniformLocation(idProgram2, "border");

        bool enableOutline = true;  // Set this to true or false as needed
        glUniform1i(useOutlineLoc, enableOutline);

        // Set the uniform variable for outline color in the fragment shader
        glLineWidth(100.0);
        glBindVertexArray(idVAO);
        glDrawArrays(GL_LINE_LOOP, 0, N);

        enableOutline = false;  // Set this to true or false as needed
        glUniform1i(useOutlineLoc, enableOutline);
    }

	// Wylaczanie
	glUseProgram( 0 );
	glutSwapBuffers();

}

// ---------------------------------------
void Initialize()
{
    calculateVertices();
	// -------------------------------------------------
	// Etap (2) przeslanie danych wierzcholk�w do OpenGL
	// -------------------------------------------------
	glGenVertexArrays( 1, &idVAO );
	glBindVertexArray( idVAO );

	// Bufor na wspolrzedne wierzcholkow
	glGenBuffers( 1, &idVBO_coord );
	glBindBuffer( GL_ARRAY_BUFFER, idVBO_coord );
	glBufferData( GL_ARRAY_BUFFER, sizeof( vertices ), vertices, GL_STATIC_DRAW );

	glVertexAttribPointer( 0, 2, GL_FLOAT, GL_FALSE, 0, NULL );
	glEnableVertexAttribArray( 0 );

	glBindVertexArray( 0 );


	// ---------------------------------------
	// Etap (3) stworzenie potoku graficznego
	// ---------------------------------------
	idProgram = glCreateProgram();

	glAttachShader( idProgram, LoadShader(GL_VERTEX_SHADER, "vertex.glsl"));
	glAttachShader( idProgram, LoadShader(GL_FRAGMENT_SHADER, "fragment.glsl"));

	LinkAndValidateProgram( idProgram );



	idProgram2 = glCreateProgram();

	glAttachShader( idProgram2, LoadShader(GL_VERTEX_SHADER, "vertex2.glsl"));
	glAttachShader( idProgram2, LoadShader(GL_FRAGMENT_SHADER, "fragment2.glsl"));

	LinkAndValidateProgram( idProgram2 );


	// -----------------------------------------
	// Etap (4) ustawienie maszyny stanow OpenGL
	// -----------------------------------------

	// ustawienie koloru czyszczenia ramki koloru
	glClearColor( 0.9f, 0.9f, 0.9f, 0.9f );

}

// ---------------------------------------
// Funkcja wywolywana podczas zmiany rozdzielczosci ekranu
void Reshape( int width, int height )
{
	glViewport( 0, 0, width, height );
}

// ---------------------------------------------------
// Funkcja wywolywana podczas wcisniecia klawisza ASCII
void Keyboard( unsigned char key, int x, int y )
{
    switch(key)
    {
		case 27:	// ESC key
			// opuszczamy glowna petle
			glutLeaveMainLoop();
			break;

		case ' ':	// Space key
			printf("SPACE!\n");
			if(spacja == true){
                glutPostRedisplay();
                spacja = false;
			}else{
			    spacja= true;
			// ponowne renderowanie
                glutPostRedisplay();
			}
			break;
    }
}


// ---------------------------------------------------
int main( int argc, char *argv[] )
{
	// -----------------------------------------------
	// Etap (1) utworzynie kontektu i okna aplikacji
	// -----------------------------------------------

	// GLUT
	glutInit( &argc, argv );
	glutInitDisplayMode( GLUT_DOUBLE | GLUT_RGB );
	glutInitContextVersion( 3, 2 );
	glutInitContextProfile( GLUT_CORE_PROFILE );
	glutInitWindowSize( 500, 500 );
	glutCreateWindow( "Szablon programu w OpenGL" );
	glutDisplayFunc( DisplayScene );
	glutReshapeFunc( Reshape );
	glutKeyboardFunc( Keyboard );


	// GLEW
	glewExperimental = GL_TRUE;
	GLenum err = glewInit();
	if( GLEW_OK != err )
	{
		printf("GLEW Error\n");
		exit(1);
	}

	// OpenGL
	if( !GLEW_VERSION_3_2 )
	{
		printf("Brak OpenGL 3.2!\n");
		exit(1);
	}

	// Inicjalizacja
	Initialize();



	glutMainLoop();


	// Cleaning
	glDeleteProgram( idProgram );
	glDeleteVertexArrays( 1, &idVBO_coord );
	glDeleteVertexArrays( 1, &idVAO );

	return 0;
}
