# lab2
## 1
![img.png](../screeny/img.png)
## 2
![img_1.png](../screeny/img_1.png)
Po spacji
![img_2.png](../screeny/img_2.png)
## 3
![img_3.png](../screeny/img_3.png)
## 4
![img.png](../screeny/img4.png)
![img.png](../screeny/img_4.png)