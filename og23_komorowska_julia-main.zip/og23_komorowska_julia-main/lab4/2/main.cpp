#include <stdio.h>
#include <GL/glew.h>
#include <GL/freeglut.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <time.h>
#include "shader_stuff.h"
#include "obj_loader.hpp"

glm::mat4 matModel;
glm::mat4 matView;
glm::mat4 matProj;

glm::mat4 matModelstozek;
glm::mat4 matModelstozek2;
glm::mat4 matModelstozek3;
glm::mat4 matModelstozek4;

GLfloat angleY;
GLfloat angleX;
GLfloat angleXstozek;
GLfloat angleYstozek;
GLfloat kamera = -5;


clock_t last_T = 0;

void Animation()
{
    clock_t now_T = clock();
    double delta_T = now_T - last_T;
    if (delta_T > 6)
    {
        angleY += 0.02f;
        glutPostRedisplay();
        last_T = now_T;
    }
}

class CProgram
{
public:
    GLuint idProgram;

    void CreateProgram()
    {
        idProgram = glCreateProgram();
    }

    void Use()
    {
        glUseProgram(idProgram);
    }

    void LoadShaders(char* vertex_filename, char* fragment_filename)
    {
        glAttachShader(idProgram, LoadShader(GL_VERTEX_SHADER, vertex_filename));
        glAttachShader(idProgram, LoadShader(GL_FRAGMENT_SHADER, fragment_filename));
    }

    void LinkAndValidate()
    {
        LinkAndValidateProgram(idProgram);
    }

    void SetMVP(glm::mat4 matModel, glm::mat4 matView, glm::mat4 matProj)
    {
        glUniformMatrix4fv(glGetUniformLocation(idProgram, "matProj"), 1, GL_FALSE, glm::value_ptr(matProj));
        glUniformMatrix4fv(glGetUniformLocation(idProgram, "matView"), 1, GL_FALSE, glm::value_ptr(matView));
        glUniformMatrix4fv(glGetUniformLocation(idProgram, "matModel"), 1, GL_FALSE, glm::value_ptr(matModel));
    }

    void Clean()
    {
        glDeleteProgram(idProgram);
    }
};

class CMesh
{
public:
    std::vector<glm::vec3> vertices;
    std::vector<glm::vec2> uvs;
    std::vector<glm::vec3> normals;
    GLuint idVAO;
    GLuint idVBO_coord;
    GLuint idVBO_color;

    void CreateFromOBJ(char* filename)
    {
        if (!loadOBJ(filename, vertices, uvs, normals))
        {
            printf("File not loaded!\n");
        }

        glGenVertexArrays(1, &idVAO);
        glBindVertexArray(idVAO);
        glGenBuffers(1, &idVBO_coord);
        glBindBuffer(GL_ARRAY_BUFFER, idVBO_coord);
        glBufferData(GL_ARRAY_BUFFER, sizeof(glm::vec3) * vertices.size(), &vertices[0], GL_STATIC_DRAW);
        glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, NULL);
        glEnableVertexAttribArray(0);
        glGenBuffers(1, &idVBO_color);
        glBindBuffer(GL_ARRAY_BUFFER, idVBO_color);
        glBufferData(GL_ARRAY_BUFFER, sizeof(glm::vec3) * normals.size(), &normals[0], GL_STATIC_DRAW);
        glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 0, NULL);
        glEnableVertexAttribArray(1);
        glBindVertexArray(0);
    }

    void Draw()
    {
        glBindVertexArray(idVAO);
        glDrawArrays(GL_TRIANGLES, 0, vertices.size());
        glBindVertexArray(0);
    }

    void Clean()
    {
        glDeleteVertexArrays(1, &idVBO_coord);
        glDeleteVertexArrays(1, &idVBO_color);
        glDeleteVertexArrays(1, &idVAO);
    }
};
int stozekNumer = 0;
CProgram myProgram, stozekProgram;
CMesh malpa, stozek;

void DisplayScene()
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    matView = glm::mat4(1.0);
    matView = glm::translate(matView, glm::vec3(0.0, 0.0, kamera));
    matModel = glm::mat4(1.0);
    matModel = glm::rotate(matModel, angleX, glm::vec3(1.0, 0.0, 0.0));
    matModel = glm::rotate(matModel, angleY, glm::vec3(0.0, 1.0, 0.0));
    myProgram.Use();
    myProgram.SetMVP(matModel, matView, matProj);
    malpa.Draw();
    glUseProgram(0);

    matModelstozek = glm::mat4(1.0);
    matModelstozek = glm::rotate(matModelstozek, angleXstozek, glm::vec3(1.0, 0.0, 0.0));
    matModelstozek = glm::rotate(matModelstozek, angleYstozek, glm::vec3(0.0, 1.0, 0.0));
    matModelstozek = glm::rotate(matModelstozek, angleY, glm::vec3(0.0, 0.0, 1.0));
    matModelstozek = glm::translate(matModelstozek, glm::vec3(0.0, 3.0, 0.0));

    stozekProgram.Use();
    glUniform1i(glGetUniformLocation(stozekProgram.idProgram, "stozekNumer"), 0);
    stozekProgram.SetMVP(matModelstozek, matView, matProj);
    stozek.Draw();
    glUseProgram(0);

    matModelstozek2 = glm::translate(matModelstozek, glm::vec3(0.0, -6.0, 0.0));
    stozekProgram.Use();
    glUniform1i(glGetUniformLocation(stozekProgram.idProgram, "stozekNumer"), 1);
    stozekProgram.SetMVP(matModelstozek2, matView, matProj);
    stozek.Draw();
    glUseProgram(0);

    matModelstozek3 = glm::translate(matModelstozek, glm::vec3(3.0, -3.0, 0.0));
    stozekProgram.Use();
    glUniform1i(glGetUniformLocation(stozekProgram.idProgram, "stozekNumer"), 2);
    stozekProgram.SetMVP(matModelstozek3, matView, matProj);
    stozek.Draw();
    glUseProgram(0);

    matModelstozek4 = glm::translate(matModelstozek, glm::vec3(-3.0, -3.0, 0.0));
    stozekProgram.Use();
    glUniform1i(glGetUniformLocation(stozekProgram.idProgram, "stozekNumer"), 3);
    stozekProgram.SetMVP(matModelstozek4, matView, matProj);
    stozek.Draw();
    glUseProgram(0);

    glutSwapBuffers();
}

void Initialize()
{
    glClearColor(0.5f, 0.5f, 0.5f, 1.0f);
    glEnable(GL_DEPTH_TEST);
    myProgram.CreateProgram();
    myProgram.LoadShaders("vertex.glsl", "fragment.glsl");
    myProgram.LinkAndValidate();
    stozekProgram.CreateProgram();
    stozekProgram.LoadShaders("vertexst.glsl", "fragmentst.glsl");
    stozekProgram.LinkAndValidate();
    malpa.CreateFromOBJ("models/monkey.obj");
    stozek.CreateFromOBJ("models/cone.obj");
}

void Reshape(int width, int height)
{
    glViewport(0, 0, width, height);
    matProj = glm::perspective(glm::radians(90.0f), width / (float)height, 0.1f, 40.0f);
}

void Keyboard(unsigned char key, int x, int y)
{
    switch (key)
    {
    case 27:
        exit(0);
        break;

    case 'w':
        angleX += 0.1f;
        angleXstozek += 0.1f;
        break;

    case 's':
        angleX -= 0.1f;
        angleXstozek -= 0.1f;
        break;

    case 'd':
        angleY -= 0.1f;
        angleYstozek -= 0.1f;
        break;

    case 'a':
        angleY += 0.1f;
        angleYstozek += 0.1f;
        break;

    case 'x':
        kamera += 0.1f;
        break;

    case 'y':
        kamera -= 0.1f;
        break;
    }
}

int main(int argc, char* argv[])
{
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitContextVersion(3, 2);
    glutInitContextProfile(GLUT_CORE_PROFILE);
    glutInitWindowSize(500, 500);
    glutCreateWindow("Wirujace");
    glutDisplayFunc(DisplayScene);
    glutReshapeFunc(Reshape);
    glutKeyboardFunc(Keyboard);

    glewExperimental = GL_TRUE;
    GLenum err = glewInit();
    if (GLEW_OK != err)
    {
        printf("GLEW Error\n");
        exit(1);
    }

    if (!GLEW_VERSION_3_2)
    {
        printf("Brak OpenGL 3.2!\n");
        exit(1);
    }

    glutIdleFunc(Animation);
    Initialize();
    glutMainLoop();

    myProgram.Clean();
    malpa.Clean();

    stozekProgram.Clean();
    stozek.Clean();

    return 0;
}
