# lab4
## 1
![img.png](../screeny/img_10.png)
Tam były próby w Pythonie ale nie wyszło. Truskawka wyglądająca jak diamencik się kręci  i szescian(wokół własnej osi)
## 2
![img_1.png](../screeny/img_11.png) filmik w webm
