from OpenGL.GL import *
class OBJ:
    def __init__(self, filename, scale=1.0):
        self.vertices = []
        self.normals = []
        self.faces = []
        self.read_obj_file(filename, scale)

    def read_obj_file(self, filename, scale):
        try:
            with open(filename, 'r') as file:
                for line in file:
                    tokens = line.split()
                    if len(tokens) == 0:
                        continue
                    if tokens[0] == 'v':
                        # Wierzchołki
                        vertex = [float(tokens[1]) * scale, float(tokens[2]) * scale, float(tokens[3]) * scale]
                        self.vertices.append(vertex)
                    elif tokens[0] == 'vn':
                        # Normalne
                        normal = [float(tokens[1]), float(tokens[2]), float(tokens[3])]
                        self.normals.append(normal)
                    elif tokens[0] == 'f':
                        # Ściany (trójkąty)
                        face = [tuple(map(int, vertex.split('/'))) for vertex in tokens[1:]]
                        self.faces.append(face)
        except FileNotFoundError:
            print(f"Nie można odnaleźć pliku {filename}")
            raise

    def draw(self):
        glBegin(GL_TRIANGLES)
        for face in self.faces:
            for vertex in face:
                vertex_index, _, normal_index = vertex
                glNormal3fv(self.normals[normal_index - 1])
                glVertex3fv(self.vertices[vertex_index - 1])
        glEnd()

