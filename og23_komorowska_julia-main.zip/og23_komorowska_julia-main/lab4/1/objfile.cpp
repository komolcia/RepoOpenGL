#include <stdio.h>
#include <GL/glew.h>
#include <GL/freeglut.h>
#include <vector>

#include "shader_stuff.h"

// ---------------------------------------
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include "obj_loader.hpp"

// ---------------------------------------
// Identyfikatory obiektów
GLuint idProgram, idProgram_minimap;    // programy shaderów
GLuint idVAO, idVBO_coord, idVBO_color; // obiekt główny
GLuint idVAO_minimap, idVBO_coord_minimap, idVBO_color_minimap; // minimapa

// ---------------------------------------
// Dane szescianu
#include "cube.h"

// Zmienne do obracania szescianem
GLfloat angleX = 0.0f;
GLfloat angleY = 0.0f;
GLfloat angleX_B = 0.0f;
GLfloat angleY_B = 0.0f;

glm::mat4 matProj;
glm::mat4 matView;

glm::mat4 matModel1;
glm::mat4 matModel2;
glm::mat4 matModel3;
glm::mat4 matModel4;

std::vector<glm::vec3> vert, vert2, vert3, vert4, vert5;
std::vector<glm::vec2> texture, texture2, texture3, texture4, texture5;
std::vector<glm::vec3> normals, normals2, normals3, normals4, normals5;

// Dodatkowa flaga do włączania/wyłączania minimapy
bool enableMinimap = true;
void RenderMinimap()
{
    glUseProgram(idProgram_minimap);

    glm::mat4 matProj_minimap = glm::ortho(-5.0f, 5.0f, -5.0f, 5.0f, 0.1f, 10.0f);
    glUniformMatrix4fv(glGetUniformLocation(idProgram_minimap, "matProj"), 1, GL_FALSE, glm::value_ptr(matProj_minimap));
    glUniformMatrix4fv(glGetUniformLocation(idProgram_minimap, "matView"), 1, GL_FALSE, glm::value_ptr(glm::mat4(1.0)));

    glm::mat4 matModel_minimap = glm::translate(glm::mat4(1.0), glm::vec3(0.0f, 0.0f, -2.0f));
    glUniformMatrix4fv(glGetUniformLocation(idProgram_minimap, "matModel"), 1, GL_FALSE, glm::value_ptr(matModel_minimap));

    glBindVertexArray(idVAO_minimap);
    glDrawArrays(GL_TRIANGLES, 0, vert.size());
    glBindVertexArray(0);

    glUseProgram(0);
}
// ---------------------------------------
void DisplayScene()
{
    // Czyszczenie bufora koloru
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    // Wlaczenie programu
    glUseProgram(idProgram);

    glUniformMatrix4fv(glGetUniformLocation(idProgram, "matProj"), 1, GL_FALSE, glm::value_ptr(matProj));
    glUniformMatrix4fv(glGetUniformLocation(idProgram, "matView"), 1, GL_FALSE, glm::value_ptr(matView));

    // Update rotation angles for animation
    angleX += 0.5f; // Adjust the speed of rotation
    angleY += 0.5f;
    angleX_B += 0.5f;
    angleY_B += 0.5f;

    // Obiekt A
    matModel1 = glm::mat4(1.0);
    matModel1 = glm::translate(matModel1, glm::vec3(0, 1, 2));
    matModel1 = glm::rotate(matModel1, glm::radians(angleX), glm::vec3(1, 0, 0));
    matModel1 = glm::rotate(matModel1, glm::radians(angleY), glm::vec3(0, 1, 0));
    matModel1 = glm::translate(matModel1, glm::vec3(0, -2, 0));

    glUniformMatrix4fv(glGetUniformLocation(idProgram, "matModel"), 1, GL_FALSE, glm::value_ptr(matModel1));
    glBindVertexArray(idVAO);
    glDrawArrays(GL_TRIANGLES, 0, vert.size());
    glBindVertexArray(0);

    // Obiekt B
    matModel2 = glm::mat4(1.0);
    matModel2 = glm::translate(matModel2, glm::vec3(2, 0, 0));
    matModel2 = glm::rotate(matModel2, glm::radians(angleX_B), glm::vec3(1, 0, 0));
    matModel2 = glm::rotate(matModel2, glm::radians(angleY_B), glm::vec3(0, 1, 0));

    glUniformMatrix4fv(glGetUniformLocation(idProgram, "matModel"), 1, GL_FALSE, glm::value_ptr(matModel2));
    glBindVertexArray(idVAO3);
    glDrawArrays(GL_TRIANGLES, 0, vert3.size());
    glBindVertexArray(0);

    // Rysuj minimapę
    if (enableMinimap)
    {
        glViewport(glutGet(GLUT_WINDOW_WIDTH) - 150, 10, 140, 140); // Dostosuj rozmiar i położenie minimapy
        RenderMinimap();
    }

    glutSwapBuffers();
}


void InitializeMinimap()
{
    glGenVertexArrays(1, &idVAO_minimap);
    glBindVertexArray(idVAO_minimap);

    glGenBuffers(1, &idVBO_coord_minimap);
    glBindBuffer(GL_ARRAY_BUFFER, idVBO_coord_minimap);
    glBufferData(GL_ARRAY_BUFFER, vert.size() * sizeof(glm::vec3), &vert[0], GL_STATIC_DRAW);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, NULL);
    glEnableVertexAttribArray(0);

    std::vector<glm::vec3> minimapColors;
    for (int i = 0; i < vert.size(); ++i) {
        minimapColors.push_back(glm::vec3(0.0f, 1.0f, 0.0f));
    }
    glGenBuffers(1, &idVBO_color_minimap);
    glBindBuffer(GL_ARRAY_BUFFER, idVBO_color_minimap);
    glBufferData(GL_ARRAY_BUFFER, minimapColors.size() * sizeof(glm::vec3), &minimapColors[0], GL_STATIC_DRAW);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 0, NULL);
    glEnableVertexAttribArray(1);

    glBindVertexArray(0);
}

void Initialize()
{
    matView = glm::mat4(1.0);
    matView = glm::translate(matView, glm::vec3(0, 0, -5));

    if (!loadOBJ("truskawka.obj", vert, texture, normals) ||
        !loadOBJ("monkey.obj", vert2, texture2, normals2) ||
        !loadOBJ("models/cube.obj", vert3, texture3, normals3) ||
        !loadOBJ("models/sphere.obj", vert4, texture4, normals4) ||
        !loadOBJ("ground.obj", vert5, texture5, normals5))
    {
        printf("Nie wczytano pliku obj!\n");
    }

    // Ustawienia OpenGL
    glClearColor(0.5f, 0.5f, 0.5f, 1.0f);
    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LESS);

    // Program shaderów dla głównego widoku
    idProgram = glCreateProgram();
    glAttachShader(idProgram, LoadShader(GL_VERTEX_SHADER, "vertex.glsl"));
    glAttachShader(idProgram, LoadShader(GL_FRAGMENT_SHADER, "fragment.glsl"));
    LinkAndValidateProgram(idProgram);

    // Program shaderów dla minimapy
    idProgram_minimap = glCreateProgram();
    glAttachShader(idProgram_minimap, LoadShader(GL_VERTEX_SHADER, "myvertex.glsl"));
    glAttachShader(idProgram_minimap, LoadShader(GL_FRAGMENT_SHADER, "myfragment.glsl"));
    LinkAndValidateProgram(idProgram_minimap);

    InitializeMinimap();
}

void Reshape(int width, int height)
{
    glViewport(0, 0, width, height);
    matProj = glm::perspective(3.14 / 3, (double)width / (double)height, 0.1, 10.0);
}

void Keyboard(unsigned char key, int x, int y)
{
    switch (key)
    {
    case 27:
        exit(0);
        break;

    case 's':
        printf("Key 's' pressed\n");
        matView = glm::rotate(matView, glm::radians(-0.5f), glm::vec3(1.0f, 0.0f, 0.0f));
        break;

    case 'w':
        printf("Key 'w' pressed\n");
        matView = glm::rotate(matView, glm::radians(0.5f), glm::vec3(1.0f, 0.0f, 0.0f));
        break;

    case 'd':
        printf("Key 'd' pressed\n");
        matView = glm::rotate(matView, glm::radians(-0.5f), glm::vec3(0.0f, 1.0f, 0.0f));
        break;

    case 'a':
        printf("Key 'a' pressed\n");
        matView = glm::rotate(matView, glm::radians(0.5f), glm::vec3(0.0f, 1.0f, 0.0f));
        break;

    case 'x':
        printf("Key 'x' pressed\n");
        matView = glm::translate(matView, glm::vec3(0.0f, 0.0f, 0.1f));
        break;

    case 'y':
        printf("Key 'y' pressed\n");
        matView = glm::translate(matView, glm::vec3(0.0f, 0.0f, -0.1f));
        break;

    // Dodaj obsługę klawisza 'm' do włączania/wyłączania minimapy
    case 'm':
        enableMinimap = !enableMinimap;
        break;
    }

    glutPostRedisplay();
}

void Timer(int value)
{
    glutPostRedisplay();
    glutTimerFunc(16, Timer, 0);
}

int main(int argc, char *argv[])
{
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitContextVersion(3, 2);
    glutInitContextProfile(GLUT_CORE_PROFILE);
    glutInitWindowSize(600, 400);
    glutCreateWindow("Obracanie klawiszami WSAD");
    glutDisplayFunc(DisplayScene);
    glutReshapeFunc(Reshape);

    // Keyboard
    glutKeyboardFunc(Keyboard);

    // Set up the timer
    glutTimerFunc(0, Timer, 0);

    // GLEW
    glewExperimental = GL_TRUE;
    GLenum err = glewInit();
    if (GLEW_OK != err)
    {
        printf("GLEW Error\n");
        exit(1);
    }

    // OpenGL
    if (!GLEW_VERSION_3_2)
    {
        printf("Brak OpenGL 3.2!\n");
        exit(1);
    }

    Initialize();
    glutMainLoop();

    // Cleaning
    glDeleteProgram(idProgram);
    glDeleteProgram(idProgram_minimap);
    glDeleteVertexArrays(1, &idVBO_coord);
	glDeleteVertexArrays( 1, &idVBO_color );
	glDeleteVertexArrays( 1, &idVAO );
		glDeleteVertexArrays( 1, &idVBO_coord2 );
	glDeleteVertexArrays( 1, &idVBO_color2 );
	glDeleteVertexArrays( 1, &idVAO2 );
			glDeleteVertexArrays( 1, &idVBO_coord3 );
    	glDeleteVertexArrays( 1, &idVBO_color3 );
    	glDeleteVertexArrays( 1, &idVAO3 );
    			glDeleteVertexArrays( 1, &idVBO_coord4 );
        	glDeleteVertexArrays( 1, &idVBO_color4 );
        	glDeleteVertexArrays( 1, &idVAO4 );
        	    			glDeleteVertexArrays( 1, &idVBO_coord5 );
                    	glDeleteVertexArrays( 1, &idVBO_color5 );
                    	glDeleteVertexArrays( 1, &idVAO5 );

	return 0;
}
