import pygame
from pygame.locals import *
from OpenGL.GL import *
from OpenGL.GLUT import *
from OpenGL.GLU import *
from objloader import *

# Inicjalizacja Pygame
pygame.init()
width, height = 800, 600
pygame.display.set_mode((width, height), DOUBLEBUF | OPENGL)
gluPerspective(45, (width / height), 0.1, 50.0)
glTranslatef(0.0, 0.0, -5)

# Kamera
camera_distance = 5.0
camera_rotation = [0, 0]

# Funkcja do rysowania podłoża
def draw_ground():
    glBegin(GL_QUADS)
    glColor3f(0.0, 0.5, 0.0)  # Zielony kolor
    glVertex3f(-2, -1, -2)
    glVertex3f(2, -1, -2)
    glVertex3f(2, -1, 2)
    glVertex3f(-2, -1, 2)
    glEnd()

# Funkcja do rysowania obiektów
def draw_objects(obj_list):
    for obj in obj_list:
        obj.draw()

# Klasa reprezentująca obiekt 3D
class Object3D:
    def __init__(self, filename, color):
        self.model = OBJ(filename)
        self.color = color
        self.angle = 0

    def draw(self):
        glPushMatrix()
        glRotatef(self.angle, 0, 1, 0)
        glColor3fv(self.color)
        self.model.draw()
        glPopMatrix()

    def update(self):
        self.angle += 1

# Inicjalizacja obiektów
ground = Object3D("ground.obj", (0.0, 0.5, 0.0))
object1 = Object3D("models/kaktus.obj", (1.0, 0.0, 0.0))  # Czerwony kolor
object2 = Object3D("monkey.obj", (0.0, 0.0, 1.0))  # Niebieski kolor
object3 = Object3D("truskawka.obj", (1.0, 1.0, 0.0))  # Żółty kolor

objects = [ground, object1, object2, object3]

# Główna pętla programu
while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            quit()

    keys = pygame.key.get_pressed()
    if keys[pygame.K_d]:
        camera_rotation[0] += 1
    if keys[pygame.K_a]:
        camera_rotation[0] -= 1
    if keys[pygame.K_s]:
        camera_rotation[1] += 1
    if keys[pygame.K_w]:
        camera_rotation[1] -= 1
    if keys[pygame.K_z]:
        camera_distance -= 0.1
    if keys[pygame.K_x]:
        camera_distance += 0.1

    glLoadIdentity()

    glTranslatef(0.0, 0.0, camera_distance)
    glRotatef(camera_rotation[1], 1, 0, 0)
    glRotatef(camera_rotation[0], 0, 1, 0)
    glTranslatef(0.0, 0.0, -camera_distance)


    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)

    # Renderowanie obiektów
    draw_ground()
    draw_objects(objects)

    # Aktualizacja obiektów (animacja)
    for obj in objects:
        obj.update()

    pygame.display.flip()
    pygame.time.wait(1)
