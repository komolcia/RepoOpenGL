void InitFrame(){
       // Inne ustawienia openGL i sceny

        glEnable( GL_DEPTH_TEST );
        glGenFramebuffers(1, &idFrameBuffer);
        glBindFramebuffer(GL_FRAMEBUFFER, idFrameBuffer);
        glGenTextures(1, &idTextureBuffer);
        glBindTexture(GL_TEXTURE_2D, idTextureBuffer);
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, Buffer_Width, Buffer_Height, 0, GL_RGB, GL_UNSIGNED_BYTE, NULL);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D,
                               idTextureBuffer, 0);
        glGenRenderbuffers(1, &idDepthBuffer);
        glBindRenderbuffer(GL_RENDERBUFFER, idDepthBuffer);
        glRenderbufferStorage(GL_RENDERBUFFER, GL_DEPTH_COMPONENT24, Buffer_Width, Buffer_Height);
        glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_RENDERBUFFER, idDepthBuffer);


        if(glCheckFramebufferStatus(GL_FRAMEBUFFER) != GL_FRAMEBUFFER_COMPLETE)
        {
            printf("Error: Framebuffer is not complete!\n");
            exit(1);
        }

        glBindFramebuffer(GL_FRAMEBUFFER, 0);
        glEnable( GL_DEPTH_TEST );
        glGenFramebuffers(1, &idPostFrameBuffer);
        glBindFramebuffer(GL_FRAMEBUFFER, idPostFrameBuffer);
        glGenTextures(1, &idPostTextureBuffer);
        glBindTexture(GL_TEXTURE_2D, idPostTextureBuffer);
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, Buffer_Width, Buffer_Height, 0, GL_RGB, GL_UNSIGNED_BYTE, NULL);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D,
                               idPostTextureBuffer, 0);
        glGenRenderbuffers(1, &idPostDepthBuffer);
        glBindRenderbuffer(GL_RENDERBUFFER, idPostDepthBuffer);
        glRenderbufferStorage(GL_RENDERBUFFER, GL_DEPTH_COMPONENT24, Buffer_Width, Buffer_Height);
        glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_RENDERBUFFER, idPostDepthBuffer);


        if(glCheckFramebufferStatus(GL_FRAMEBUFFER) != GL_FRAMEBUFFER_COMPLETE)
        {
            printf("Error: Framebuffer is not complete!\n");
            exit(1);
        }

        glBindFramebuffer(GL_FRAMEBUFFER, 0);
}