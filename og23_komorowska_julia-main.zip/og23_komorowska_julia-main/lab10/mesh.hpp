#include <GL/glew.h>
#include <GL/freeglut.h>
#include <fstream>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <time.h>
#include <SOIL/SOIL.h>
#include <GL/glew.h>
#include <GL/freeglut.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <random>
#include <string>
bool useBlinnPhong = false;
bool usePhongReflect=false;
const int Number_of_Raven = 1000;
bool useLight = false;
bool animatePoint = false;
bool point = false;
int color= 0;
bool isDirectionalLight = false;
bool showPointLightSpheres=false;
bool postprocessing = false;
bool changeSkybox = true;
bool isReflectOn = true;
float Time =0.0f;
bool heightBool= true;
bool splotEffect = false;
bool funEffect = false;
bool useShadowMapping=false;
bool useShadowCubeMapping=false;
clock_t last_T = 0;

bool showMinimap = true; // Flaga do włączania/wyłączania minimapy
GLuint idFrameBuffer;   // FBO
GLuint idDepthBuffer;	// Bufor na skladowa glebokosci
GLuint idTextureBuffer; // Tekstura na skladowa koloru

GLuint idPostFrameBuffer;   // FBO
GLuint idPostDepthBuffer;	// Bufor na skladowa glebokosci
GLuint idPostTextureBuffer; // Tekstura na skladowa koloru

GLuint vBuffer_pos;
GLuint vBuffer_uv;
GLuint vBuffer_normal;
GLuint vArray;

GLuint vBuffer_posPost;
GLuint vBuffer_uvPost;
GLuint vBuffer_normalPost;
GLuint vArrayPost;

// Rozdzielczosc FBO
int Buffer_Width = 256;
int Buffer_Height = 256;

CSkyBox skybox=CSkyBox();

glm::mat4 matModel;
glm::mat4 matModel2;
glm::mat4 matView;
glm::mat4 matProj;

glm::mat4 matModelGhost;
glm::mat4 matModelGrave;
glm::mat4 matModelCube;
glm::mat4 matModelSphere;
glm::mat4 matModelRaven;

glm::mat4x4 Table_of_Raven_matModel[Number_of_Raven];

GLfloat angleY;
GLfloat angleX;
GLfloat angleXCube;
GLfloat angleYCube;
GLfloat redIntensity;
GLfloat height=2;
GLfloat cameraDistance=-10;
float lightMovementSpeed = 0.1f;
float lightPositionX = 2.0f;

GLfloat vertices_pos[] =
{
    0.5f, 0.5f, 0.0f,
    1.5f, 0.5f, 0.0f,
    1.5f, 1.5f, 0.0f,

    1.5f, 1.5f, 0.0f,
    0.5f, 1.5f, 0.0f,
    0.5f, 0.5f, 0.0f,



};
GLfloat vertices_posPost[] =
{
    -2.0f, -2.0f, 0.0f,  // lewy dolny róg
        2.0f, -2.0f, 0.0f,   // prawy dolny róg
        2.0f, 2.0f, 0.0f,    // prawy górny róg

        2.0f, 2.0f, 0.0f,    // prawy górny róg
        -2.0f, 2.0f, 0.0f,   // lewy górny róg
        -2.0f, -2.0f, 0.0f,  // lewy dolny róg
    };

GLfloat vertices_tex[] =
{
    0.0f, 0.0f,
    1.0f, 0.0f,
    1.0f, 1.0f,

    1.0f, 1.0f,
    0.0f, 1.0f,
    0.0f, 0.0f,
};
GLfloat vertices_texPost[] =
{
    0.0f, 0.0f,
    1.0f, 0.0f,
    1.0f, 1.0f,

    1.0f, 1.0f,
    0.0f, 1.0f,
    0.0f, 0.0f,
};
Texture LoadTexture(const char* filename);
class CProgram
{
public:
    GLuint idProgram;
    void CreateProgram()
    {
        idProgram = glCreateProgram();
    }
    void Use()
    {
        glUseProgram( idProgram );
    }
    void LoadShaders(char* vertex_filename, char* fragment_filename)
    {
        glAttachShader( idProgram, LoadShader(GL_VERTEX_SHADER, vertex_filename));
        glAttachShader( idProgram, LoadShader(GL_FRAGMENT_SHADER, fragment_filename));
    }
    void LinkAndValidate()
    {
        LinkAndValidateProgram( idProgram );
    }
    void SetMVP(glm::mat4 matView,glm::mat4 matProj,bool useTexture,bool isCube)
    {
        glm::vec3 cameraPos = ExtractCameraPos(matView);
        glUniformMatrix4fv( glGetUniformLocation(idProgram, "matProj"), 1, GL_FALSE, glm::value_ptr(matProj) );
        glUniformMatrix4fv( glGetUniformLocation(idProgram, "matView"), 1, GL_FALSE, glm::value_ptr(matView) );
        glUniform1i(glGetUniformLocation(idProgram, "useTexture"), useTexture);
        glUniform1i(glGetUniformLocation(idProgram, "isCube"), isCube);


        glUniform1i(glGetUniformLocation(idProgram, "isDirectionalLight"), isDirectionalLight);
        glUniform3fv(glGetUniformLocation(idProgram,"myLight.Direction"), 1, glm::value_ptr(myLight.Position));
        glUniform1i(glGetUniformLocation(idProgram,"showPointLightSpheres"), showPointLightSpheres);
        glUniform1i(glGetUniformLocation(idProgram, "punkt"), point);
        glUniform1i(glGetUniformLocation(idProgram, "usePhongReflect"), usePhongReflect);

        glUniform3fv( glGetUniformLocation( idProgram, "cameraPos" ), 1, &cameraPos[0] );

        SentLightParameters();

    }
    void SetMVPMultiple(glm::mat4 matView,glm::mat4 matProj,bool useTexture,bool isCube)
    {
        glm::vec3 cameraPos = ExtractCameraPos(matView);
        glUniformMatrix4fv( glGetUniformLocation(idProgram, "matProj"), 1, GL_FALSE, glm::value_ptr(matProj) );
        glUniformMatrix4fv( glGetUniformLocation(idProgram, "matView"), 1, GL_FALSE, glm::value_ptr(matView) );
        glUniform1i(glGetUniformLocation(idProgram, "useTexture"), useTexture);
        glUniform1i(glGetUniformLocation(idProgram, "isCube"), isCube);

        glUniform3fv( glGetUniformLocation( idProgram, "cameraPos" ), 1, glm::value_ptr(cameraPos) );
        glUniform1i(glGetUniformLocation(idProgram, "isDirectionalLight"), isDirectionalLight);
        glUniform3fv(glGetUniformLocation(idProgram,"myLight.Direction"), 1, glm::value_ptr(myLight.Position));
        glUniform1i(glGetUniformLocation(idProgram,"showPointLightSpheres"), showPointLightSpheres);
        glUniform1i(glGetUniformLocation(idProgram, "punkt"), point);
        glUniform1i(glGetUniformLocation(idProgram, "usePhongReflect"), usePhongReflect);

        glUniform3fv( glGetUniformLocation( idProgram, "cameraPos" ), 1, &cameraPos[0] );
    }
    void SendInt(GLchar* name, int number)
    {
        glUniform1i(glGetUniformLocation(idProgram, name), number);
    }
    void SendFloat(GLchar* name, float number)
    {
        glUniform1f(glGetUniformLocation(idProgram, name), number);
    }
    void SendMaterial(MaterialParam myMaterial)
    {
        glUniform3fv(glGetUniformLocation(idProgram,"myMaterial.Ambient"), 1, glm::value_ptr(myMaterial.Ambient));
        glUniform3fv(glGetUniformLocation(idProgram,"myMaterial.Diffuse"), 1, glm::value_ptr(myMaterial.Diffuse));
        glUniform3fv(glGetUniformLocation(idProgram,"myMaterial.Specular"), 1, glm::value_ptr(myMaterial.Specular));
        glUniform1f(glGetUniformLocation(idProgram,"myMaterial.Shininess"), myMaterial.Shininess);
    }
    void Clean()
    {
        glDeleteProgram( idProgram );
    }

};
void initializeMatrices()
{
    std::default_random_engine generator;
    std::uniform_real_distribution<float> distribution(-10.0f, 10.0f);

    for (int i = 0; i < Number_of_Raven; ++i)
    {
        float x = distribution(generator);
        float y = distribution(generator);
        float z = distribution(generator);
        float scale = distribution(generator) / 10.0f;
        float angle = distribution(generator);

        Table_of_Raven_matModel[i] = glm::translate(glm::mat4(1.0f), glm::vec3(x, y, z));
        Table_of_Raven_matModel[i] = glm::rotate(Table_of_Raven_matModel[i], angle, glm::vec3(0.0f, 1.0f, 0.0f));
        Table_of_Raven_matModel[i] = glm::scale(Table_of_Raven_matModel[i], glm::vec3(scale, scale, scale));
    }
}
class CMesh
{
public:
    std::vector<glm::vec3> vertices;
    std::vector<glm::vec2> uvs;
    std::vector<glm::vec3> normals;
    GLuint idVAO;		// tablic wierzcholkow
    GLuint idVBO_coord;	// bufor wspolrzednych
    GLuint idVBO_color; // bufor na kolory
    GLuint idVBO_texCoord;  // bufor na współrzęd
    GLuint idVBO_normal; // bufor na koloryne tekstur

    Material material;  // informacje o materiale

    void CreateFromOBJ(char* filename)
    {

        // Wczytanie pliku OBJ
        if (!loadOBJ(filename, vertices, uvs, normals))
        {
            printf("File not loaded!\n");
        }

        printf("Loaded %d vertices\n", vertices.size());
        glGenVertexArrays( 1, &idVAO );
        glBindVertexArray( idVAO );
        glGenBuffers( 1, &idVBO_coord );
        glBindBuffer( GL_ARRAY_BUFFER, idVBO_coord );
        glBufferData( GL_ARRAY_BUFFER, sizeof( glm::vec3 ) * vertices.size(), &vertices[0], GL_STATIC_DRAW );
        glVertexAttribPointer( 0, 3, GL_FLOAT, GL_FALSE, 0, NULL );
        glEnableVertexAttribArray( 0 );
        glGenBuffers( 1, &idVBO_normal );
        glBindBuffer( GL_ARRAY_BUFFER, idVBO_normal );
        glBufferData( GL_ARRAY_BUFFER, normals.size() * sizeof(glm::vec3), &normals[0], GL_STATIC_DRAW );
        glVertexAttribPointer( 1, 3, GL_FLOAT, GL_FALSE, 0, NULL );
        glEnableVertexAttribArray( 1);
        glGenBuffers( 1, &idVBO_texCoord );
        glBindBuffer( GL_ARRAY_BUFFER, idVBO_texCoord );
        glBufferData( GL_ARRAY_BUFFER, sizeof( glm::vec2 ) * uvs.size(), &uvs[0], GL_STATIC_DRAW );
        glVertexAttribPointer( 2, 2, GL_FLOAT, GL_FALSE, 0, NULL );
        glEnableVertexAttribArray( 2 );
        glBindVertexArray( 0 );


    }
    void CreateFromObjMultiple(char* filename)
    {
        // Wczytanie pliku OBJ
        if (!loadOBJ(filename, vertices, uvs, normals))
        {
            printf("File not loaded!\n");
        }

        printf("Loaded %d vertices\n", vertices.size());

        glGenVertexArrays( 1, &idVAO );
        glBindVertexArray( idVAO );

        glGenBuffers( 1, &idVBO_coord );
        glBindBuffer( GL_ARRAY_BUFFER, idVBO_coord );
        glBufferData( GL_ARRAY_BUFFER, sizeof( glm::vec3 ) * vertices.size(), &vertices[0], GL_STATIC_DRAW );
        glVertexAttribPointer( 0, 3, GL_FLOAT, GL_FALSE, 0, NULL );
        glEnableVertexAttribArray( 0 );

        glGenBuffers( 1, &idVBO_texCoord );
        glBindBuffer( GL_ARRAY_BUFFER, idVBO_texCoord );
        glBufferData( GL_ARRAY_BUFFER, sizeof( glm::vec2 ) * uvs.size(), &uvs[0], GL_STATIC_DRAW );
        glVertexAttribPointer( 1, 2, GL_FLOAT, GL_FALSE, 0, NULL );
        glEnableVertexAttribArray( 1 );

        glGenBuffers( 1, &idVBO_normal );
        glBindBuffer( GL_ARRAY_BUFFER, idVBO_normal );
        glBufferData( GL_ARRAY_BUFFER, normals.size() * sizeof(glm::vec3), &normals[0], GL_STATIC_DRAW );
        glVertexAttribPointer( 2, 3, GL_FLOAT, GL_FALSE, 0, NULL );
        glEnableVertexAttribArray( 2);

        GLuint vInstances;
        glGenBuffers(1, &vInstances);
        initializeMatrices();
        glBindBuffer(GL_ARRAY_BUFFER, vInstances);
        glBufferData(GL_ARRAY_BUFFER, Number_of_Raven * sizeof(glm::mat4), &Table_of_Raven_matModel[0], GL_STATIC_DRAW);

        glVertexAttribPointer(3, 4, GL_FLOAT, GL_FALSE, sizeof(glm::mat4), (void*)0);
        glEnableVertexAttribArray(3);
        glVertexAttribPointer(4, 4, GL_FLOAT, GL_FALSE, sizeof(glm::mat4), (void*)(sizeof(glm::vec4)));
        glEnableVertexAttribArray(4);
        glVertexAttribPointer(5, 4, GL_FLOAT, GL_FALSE, sizeof(glm::mat4), (void*)(2 * sizeof(glm::vec4)));
        glEnableVertexAttribArray(5);
        glVertexAttribPointer(6, 4, GL_FLOAT, GL_FALSE, sizeof(glm::mat4), (void*)(3 * sizeof(glm::vec4)));
        glEnableVertexAttribArray(6);

        glVertexAttribDivisor(3, 1);
        glVertexAttribDivisor(4, 1);
        glVertexAttribDivisor(5, 1);
        glVertexAttribDivisor(6, 1);
        glBindVertexArray( 0 );

    }

    void Draw(glm::mat4 matModelForDraw)
    {
        GLint idProgram = 0;
        glGetIntegerv(GL_CURRENT_PROGRAM, &idProgram);
        glUniformMatrix4fv( glGetUniformLocation(idProgram, "matModel"), 1, GL_FALSE, glm::value_ptr(matModelForDraw) );
        glBindVertexArray( idVAO );
        glDrawArrays( GL_TRIANGLES, 0, vertices.size() );
        glBindVertexArray( 0 );
    }
    void DrawMultiple(glm::mat4 matModelForDraw)
    {
        GLint idProgram = 0;
        glGetIntegerv(GL_CURRENT_PROGRAM, &idProgram);
        glUniformMatrix4fv( glGetUniformLocation(idProgram, "matModel"), 1, GL_FALSE, glm::value_ptr(matModelForDraw) );
        glBindVertexArray( idVAO );
        glDrawArraysInstanced( GL_TRIANGLES, 0, vertices.size(), Number_of_Raven);
        glBindVertexArray( 0 );

    }
    void Clean()
    {
        glDeleteVertexArrays( 1, &idVBO_coord );
        glDeleteVertexArrays( 1, &idVBO_texCoord );
        glDeleteVertexArrays( 1, &idVBO_color );
        glDeleteVertexArrays( 1, &idVAO );
    }

};

Texture LoadTexture(const char* filename)
{
    Texture texture;
    glGenTextures(1, &texture.id);
    glBindTexture(GL_TEXTURE_2D, texture.id);

    int width, height,n;
    unsigned char* image = stbi_load (filename, &width, &height, &n,0);

    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);


    texture.width = width;
    texture.height = height;

    return texture;
}
void MakeSquare()
{
    glGenVertexArrays( 1, &vArray );
    glBindVertexArray( vArray );

    glGenBuffers( 1, &vBuffer_pos );
    glBindBuffer( GL_ARRAY_BUFFER, vBuffer_pos );
    glBufferData( GL_ARRAY_BUFFER, sizeof(vertices_pos), vertices_pos, GL_STATIC_DRAW );
    glVertexAttribPointer( 0, 3, GL_FLOAT, GL_FALSE, 0, NULL );
    glEnableVertexAttribArray( 0 );

    glGenBuffers( 1, &vBuffer_uv );
    glBindBuffer( GL_ARRAY_BUFFER, vBuffer_uv );
    glBufferData( GL_ARRAY_BUFFER, sizeof(vertices_tex), vertices_tex, GL_STATIC_DRAW );
    glVertexAttribPointer( 1, 2, GL_FLOAT, GL_FALSE, 0, NULL );
    glEnableVertexAttribArray( 1 );

}
void MakeRectangle()
{
    glGenVertexArrays( 1, &vArrayPost );
    glBindVertexArray( vArrayPost );

    glGenBuffers( 1, &vBuffer_posPost );
    glBindBuffer( GL_ARRAY_BUFFER, vBuffer_posPost );
    glBufferData( GL_ARRAY_BUFFER, sizeof(vertices_posPost), vertices_posPost, GL_STATIC_DRAW );
    glVertexAttribPointer( 0, 3, GL_FLOAT, GL_FALSE, 0, NULL );
    glEnableVertexAttribArray( 0 );

    glGenBuffers( 1, &vBuffer_uvPost );
    glBindBuffer( GL_ARRAY_BUFFER, vBuffer_uvPost );
    glBufferData( GL_ARRAY_BUFFER, sizeof(vertices_texPost), vertices_texPost, GL_STATIC_DRAW );
    glVertexAttribPointer( 1, 2, GL_FLOAT, GL_FALSE, 0, NULL );
    glEnableVertexAttribArray( 1 );

}

