# lab10
## Zrealizowane 2 zadania
Po kliknieciu na shadow cube map zawsze zmienia się położenie światła ale tylko jednego

![img.png](../screeny/img_16.png)
